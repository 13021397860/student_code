#include "console.h"

int main()
{
    Console t;
    t.open();
    return 0;
}
