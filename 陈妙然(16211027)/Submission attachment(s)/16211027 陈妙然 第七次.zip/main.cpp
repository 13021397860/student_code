#include "Console.h"
using namespace std;
int main()
{
    Console console;
    console.run();
}
