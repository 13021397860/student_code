#include"Console.h"
int main()
{
	Console G;
	G.student();
	system("pause");
	return 0;
}