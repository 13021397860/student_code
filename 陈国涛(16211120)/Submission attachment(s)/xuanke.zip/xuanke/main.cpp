#include <iostream>
#include "Student.h"
#include "xuanke.h"
using namespace std;

int main()
{
    xuanke x;
    x.run();

}
