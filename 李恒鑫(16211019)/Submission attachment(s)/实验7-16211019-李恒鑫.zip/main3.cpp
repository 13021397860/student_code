
#include "Console.h"

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
using namespace std;
int main(int argc, char** argv) {

	Console con;
	con.run();
	return 0;
}
