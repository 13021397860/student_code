#include "Exception.h"

Exception::Exception()
{
    //ctor
}

Exception::~Exception()
{
    //dtor
}
