#include "Course.h"

Course::Course(const string &n, int ch)
{
    name=n;
    creditHour=ch;
}

Course::~Course()
{
    //dtor
}
ostream& operator<<(ostream &output, const Course&c)
{
	output<<"�γ�����"<<c.name
		<<"\tѧ�֣�"<<c.creditHour
		<<"\t�ɼ���"<<c.getScore()
		<<"\n";
	return output;
}
void throwException() throw(exception){
    try{
        cout<<"Function throwException\n";
        throw exception();
    }catch (exception e){
        cout<<"Exception handled in function throwException\n";
        throw;
    }
    cout<<"This also should not print\n";
}

class DivideByZeroException{
public:
    DivideByZeroException()
      :message("attempted to divide by zero"){ };
    const char* what() const {return message};
private:
    const char *message;
};
double Div(int dividend, int divisor){
    if (divisor == 0)
        throw DivideByZeroException();
    return static_cast<double>(dividend)/divisor;
}



