#ifndef CHOOSEEX_H
#define CHOOSEEX_H
#include"MyException.h"
class ChooseEx : public MyException
{
	public:
		ChooseEx();
		~ChooseEx();
};

#endif
