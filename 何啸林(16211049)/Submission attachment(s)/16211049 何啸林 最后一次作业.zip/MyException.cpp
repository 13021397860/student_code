#include "MyException.h"
MyException::MyException()
{}
MyException::~MyException()
{}
string MyException::DateExw="\n****WARNING: Date input illegally ****\n";
string MyException::ChooseExw="\n****WARNING: input over range ****\n";
string MyException::InputExw="\n****WARNING: input illegally ****\n";
