#include "Date.h"
#include<iostream>
#include<iomanip>
using namespace std;

Date::Date()
{	year=month=day=1;	}
Date::Date(int y,int m,int d)
{
	setdate(y,m,d);
}
Date::~Date()
{}
Date::Date(const Date &xx)
{
	year=xx.year;
	month=xx.month;
	day=xx.day;
}
bool Date::IsleapYear() const
{
	if((year%4==0)&&(year%100!=0||year%400==0))	return true;
	else return false;
}
Date& Date::nextDay()
{
	day+=1;
	if(!Date::checkleg())
	{
		day=1;month+=1;
		if(!checkleg())
		{
			month=1;year+=1;
		}
	}
	return *this;
}
Date& Date::setyear(int x)
{
	if( x<=0 ) x=1;
	year=x;
	return *this;
}
Date& Date::setmonth(int x)
{
	month=x;
	if(!checkleg()) month=1;
	return *this;
}
Date& Date::setday(int x)
{
	day=x;
	if(!checkleg()) day=1;
	return *this;
}
Date& Date::setdate(int y,int m,int d)
{
	bool tag_ex_date=true;
	if( y>0 ) year=y;
		else year=1,tag_ex_date=false;
	if( m>0&&m<=12 ) month=m; 
		else month=1,tag_ex_date=false;
	day=d;
	if(checkleg()) ;
	else day=1,tag_ex_date=false;
	try
	{
		if( !tag_ex_date )
			throw( DateEx() );
	}catch( DateEx) {cout<<MyException::DateExw<<endl;} 
	return *this;
}
int Date::getyear() const
{return year;}
int Date::getmonth() const
{return month;}
int Date::getday() const
{return day;}
bool Date::checkleg() const
{
	if(year<1) return false; 
	if(month<1||month>12) return false;
	switch(month)
	{
		case 1: case 3: case 5: case 7: case 8: case 10: case 12:
			if(day>0&&day<=31) return true;
			else return false;
			break;
		case 4: case 6: case 9: case 11:
			if(day>0&&day<=30) return true;
			else return false;
			break;
		case 2:
			if(Date::IsleapYear())
			{
				if(day>0&&day<=29) return true;
				else return false;
				break;
			}
			else
			{
				if(day>0&&day<=28) return true;
				else return false;
				break;
			}
	}
}
Date& Date::operator++()	//ǰ�� 
{
	nextDay();
	return *this;
}
Date& Date::operator++(int)		//���� 
{
	nextDay();
	return *this;
}
Date& Date::operator+(int a)
{
	for(int i=1;i<=a;i++)
		nextDay();
	return *this;
}
istream &operator>>(istream &input,Date& a)
{
	int y,m,d;
	input>>y>>m>>d;
	a.setdate(y,m,d);
	return input;
}
ostream &operator<<(ostream &output,const Date& a)
{
	output<<a.getyear()
		  <<"-"<<a.getmonth()
		  <<"-"<<a.getday();
	return output;
}
