#ifndef Console_H
#define Console_H
#define MAX_SIZE 100
#include<iostream>
#include<cstdlib>
#include"ObligatoryCourse.h"
#include"ElectiveCourse.h"
#include"Course.h"
#include"Date.h"
#include"Student.h"
#include"MyException.h"
#include"ChooseEx.h"
#include"InputEx.h"
class Console
{
	public:
		static void choose(Student&);
		static void remove(Student&);
		static void getgrade(Student&);
		static void getGPA(Student&);
		static void setgrade(Student&);
		static void run(Student&);
		static void addOC(const ObligatoryCourse&);
		static void addEC(const ElectiveCourse&);
		static void MakeCourseList();
		static ObligatoryCourse getOC(const int&);
		static ElectiveCourse getEC(const int&);
	protected:
	private:
		static ObligatoryCourse OCourse[MAX_SIZE];
		static int ONum;
		static ElectiveCourse ECourse[MAX_SIZE];
		static int ENum;
		static int GetNumFromK(string);
};

#endif
