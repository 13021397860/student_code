#include"Console.h" 
#include"Student.h"
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main()
{
	Student stu;
	Console::MakeCourseList();
	Console::run(stu);
	return 0;
}
