#include "InputEx.h"
InputEx::InputEx()
{}
InputEx::~InputEx()
{}
