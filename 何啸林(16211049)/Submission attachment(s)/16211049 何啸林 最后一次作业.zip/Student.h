#ifndef STUDENT_H
#define STUDENT_H
#define MAX_SIZE 100
#define WeightOfObligatoryCourse 0.6
#define WeightOfElectiveCourse 0.4
#include"Date.h"
#include"Course.h"
#include<typeinfo>
class Student
{
	public:
		static int count;
		static int getcount();
		Student();
		Student(char*,int,int,int);
		Student(const Student&);
		virtual ~Student();
		char* getname() const;
		void setname(char*);
		Date getbirth() const;
		int getcourseNumber() const;
		Course& getcourseList(int) const;
		void printbirth() const;
		Student& setbirth(int,int,int);
		Student& setbirth(const Date&);
		virtual Student& addCourse(Course*);
		bool removeCourse(int);
		friend ostream& operator<<(ostream&,const Student&);
		double calcCredit() const;
	protected:
	private:
		char *name;
		Date birthDate;
		Course* courseList[MAX_SIZE];
		int courseNumber;
};

#endif
