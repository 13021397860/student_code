#include "Console.h"
#include<typeinfo> 
using namespace std;
ObligatoryCourse Console::OCourse[MAX_SIZE]={};
int Console::ONum=0;
ElectiveCourse Console::ECourse[MAX_SIZE]={};
int Console::ENum=0;
void Console::choose(Student& stu)
{
	int x,xx;string ss;string s;
	cout<<"choose 1 to get Obligatorycourse, 2 to get Electivecourse, 0 to stop choosing"<<endl;
	cin>>s;
	try
	{
		x=GetNumFromK(s);
		if(x==-1) throw 1;
	if(x==1)
	{
		cout<<"Obligatory course is following: "<<endl;
		for(int i=0;i<ONum;i++)
			cout<<'\t'<<i<<"."<<getOC(i).getname()<<", CreditHour: "<<getOC(i).getcreditHour()<<endl;
		cout<<"enter the num of the course for adding: ";
		cin>>s;
		try
		{
			xx=GetNumFromK(s);
			if(xx==-1) throw InputEx();
			try
			{
				if(xx>=0&&xx<ONum) 
				{
					stu.addCourse(*getOC(xx));
				}
				else throw ChooseEx();
			}catch(ChooseEx) {cout<<MyException::ChooseExw<<endl;}
		}catch(InputEx){cout<<MyException::InputExw<<endl;cin.ignore();}
	}
	else if(x==2)
	{
		cout<<"Elective course is following: "<<endl;
		for(int i=0;i<ENum;i++)
			cout<<'\t'<<i<<"."<<getEC(i).getname()<<", CreditHour: "<<getEC(i).getcreditHour()<<endl;
		cout<<"enter the num of the course for adding: ";cin>>s;
		try
		{
			xx=GetNumFromK(s);
			if(xx==-1) throw InputEx();
			try
			{
				if(xx>=0&&xx<ENum) 
				{
					stu.addCourse(*getEC(xx));
				}
				else throw ChooseEx();
			}catch(ChooseEx) {cout<<MyException::ChooseExw<<endl;}
		}catch(InputEx){cout<<MyException::InputExw<<endl;cin.ignore();}
	}
	else
		throw ChooseEx();
	}catch(ChooseEx) {cout<<MyException::ChooseExw<<endl;}
}
void Console::remove(Student& stu)
{
	string s;
	if(stu.getcourseNumber()==0) {cout<<"there's no course to remove"<<endl;return ;}
	int x;
	for(int i=0;i<stu.getcourseNumber();i++)
	{
		cout<<'\t'<<i<<"."<<stu.getcourseList(i).getname()<<endl;
	}
	cout<<"enter the num of the course for removing: ";
	cin>>s;
	try
	{
		x=GetNumFromK(s);
		if(x==-1) throw InputEx();
		try
		{
			if(x>=0&x<stu.getcourseNumber())
				if(stu.removeCourse(x))
					cout<<"removing successfully"<<endl;
				else cout<<"wrony removing"<<endl;
			else
				throw ChooseEx();
		}catch(ChooseEx) {cout<<MyException::ChooseExw<<endl;}
	}catch(InputEx){cout<<MyException::InputExw<<endl;cin.ignore();}
}
void Console::getgrade(Student& stu)
{
	string s;
	if(stu.getcourseNumber()==0) {cout<<"there's no course to get grade"<<endl;return ;}
	int x;
	for(int i=0;i<stu.getcourseNumber();i++)
	{
		cout<<'\t'<<i<<"."<<stu.getcourseList(i).getname()<<endl;
	}
	cout<<"enter the num of the course for getting grade: ";
	cin>>s;
	try
	{
		x=GetNumFromK(s);
		if(x==-1) throw InputEx();
	}catch(InputEx){cout<<MyException::InputExw<<endl;cin.ignore();}
	if(x>=0&x<stu.getcourseNumber())
		cout<<"the grade of \""<<stu.getcourseList(x).getname()<<"\" is "<<stu.getcourseList(x).getScore()<<endl;
	else
		cout<<MyException::ChooseExw<<endl;
}
void Console::getGPA(Student& stu)
{
	if(stu.getcourseNumber()==0) {cout<<"there's no course in the course list"<<endl;return ;}
	cout<<"the GPA is "<<stu.calcCredit()<<endl;
}
void Console::setgrade(Student& stu)
{
	string s;
	if(stu.getcourseNumber()==0) {cout<<"there's no course to set grade"<<endl;return ;}
	int x;
	for(int i=0;i<stu.getcourseNumber();i++)
	{
		cout<<'\t'<<i<<"."<<stu.getcourseList(i).getname()<<", the score is "<<stu.getcourseList(i).getScore()<<endl;
	}
	cout<<"enter the num of the course for setting grade: ";
	cin>>s;
	try
	{
		x=GetNumFromK(s);
		if(x==-1) throw InputEx();
		if(x<0||x>=stu.getcourseNumber())
			cout<<MyException::ChooseExw<<endl;
		else
		{
			if(typeid(stu.getcourseList(x))==typeid(ObligatoryCourse))
			{
				int x_z;
				cout<<"set the grade of Obligatory course"<<stu.getcourseList(x).getname()<<" (0~100): ";
				while(cin>>s)
				{
					try
					{
						x_z=GetNumFromK(s);
						if(x_z==-1) throw InputEx();
						try
						{
							if( x_z<0||x_z>100 ) throw ChooseEx();
							else { cout<<"set successfully"<<endl; }
						}catch(ChooseEx) {cout<<MyException::ChooseExw<<" please enter again ";continue;}
						dynamic_cast<ObligatoryCourse&>(stu.getcourseList(x)).setScore(x_z); 
						break;
					}catch(InputEx){cout<<MyException::InputExw<<endl;cin.ignore();}
				}
			}
			else if(typeid(stu.getcourseList(x))==typeid(ElectiveCourse))
			{
				char c_z;
				cout<<"set the grade of Elective course"<<stu.getcourseList(x).getname()<<" (A~E): ";
				while(cin>>s)
				{
					try
					{
						if(s.size()>1) throw InputEx();
						else if(!( ( s[0]>='A'&&s[0]<='Z' )||( s[0]>='a'&&s[0]<='z' ) )) throw InputEx();
						else c_z=s[0];
						try
						{
//							if( c_z<'A'||(c_z>'E'&&c_z<'a')||c_z>'e' ) throw ChooseEx();
							if(!( ( c_z>='A'&&c_z<='E' )||( c_z>='a'&&c_z<='e' ) )) throw ChooseEx();
							else { cout<<"set successfully"<<endl; }
						}catch(ChooseEx) {cout<<MyException::ChooseExw<<" please enter again ";continue;}
						dynamic_cast<ElectiveCourse&>(stu.getcourseList(x)).setgrade(c_z);
						break;
					}catch(InputEx){cout<<MyException::InputExw<<endl;cin.ignore();}
				}
			}
			else cout<<"WRONY!!!"<<endl;
		}
	}catch(InputEx){cout<<MyException::InputExw<<endl;cin.ignore();}
}
void Console::run(Student& stu)
{
	char c[100];Date date;int option;char c_z;string s;
	cout<<"input student's info"<<endl;
	cout<<"name:";cin>>c;
	stu.setname(c);
	cout<<"birthday (XXXX XX XX)"<<endl;cin>>date;
	stu.setbirth(date);
	cout<<stu<<endl;
	cout<<"1.add course "<<'\n'<<"2.remove course"<<'\n'<<"3.set grade"<<'\n'
		<<"4.get grade"<<'\n'<<"5.get GPA"<<'\n';
	cout<<"*enter num to choose operation��0 to exit"<<endl;
	cin>>s;
	try
	{
		option=GetNumFromK(s);
		if(option==-1) throw InputEx();
	}catch(InputEx){cout<<MyException::InputExw<<endl;cin.ignore();option=rand()+10;}
	while(option)
	{
		try
		{switch(option)
		{
			case 1:
				choose(stu);break;
			case 2:
				remove(stu);break;
			case 3:
				setgrade(stu);break;
			case 4:
				getgrade(stu);break;
			case 5:
				getGPA(stu);break;
			default:
				throw ChooseEx();
		}}
		catch(ChooseEx) {cout<<MyException::ChooseExw<<endl;}
		cout<<endl<<"*****************************************YOH***********************************************"<<endl;
		cout<<endl<<"1.add course "<<'\n'<<"2.remove course"<<'\n'<<"3.set grade"<<'\n'
			<<"4.get grade"<<'\n'<<"5.get GPA"<<'\n';
		cout<<"*enter num to choose operation��choose 0 to exit"<<endl;
		cin>>s;
		try
		{
			option=GetNumFromK(s);
			if(option==-1) throw InputEx();
		}catch(InputEx){cout<<MyException::InputExw<<endl;cin.ignore();}
	}
	ofstream outfile("Course&student.txt",ios::app);
	outfile<<stu;
	outfile.close(); 
}
void Console::MakeCourseList()
{
	char s[200];int point;char c_z;
	ifstream infile;
	infile.open("ObligatoryCourse.txt");
	if(!infile.is_open()) cout<<"no ObligatoryCourse file"<<endl;
	else while(!infile.eof())
	{
		infile.getline(s,200,';');
		infile>>point;infile.get(c_z);
		addOC(ObligatoryCourse(s,point));
	}
	infile.close();
	infile.open("ElectiveCourse.txt");
	if(!infile.is_open()) cout<<"no ElectiveCourse file"<<endl;
	else while(!infile.eof())
	{
		infile.getline(s,200,';');
		infile>>point;infile.get(c_z);
		addEC(ElectiveCourse(s,point));
	}
	infile.close();	
}
void Console::addEC(const ElectiveCourse& a)
{
	ECourse[ENum]=a;
	ENum++;
}
void Console::addOC(const ObligatoryCourse& a)
{
	OCourse[ONum]=a;
	ONum++;
}
ObligatoryCourse Console::getOC(const int& x)
{
	return OCourse[x];
}
ElectiveCourse Console::getEC(const int& a)
{
	return ECourse[a];
}
int Console::GetNumFromK(string s)
{
	int i_z=0;
	for(int i=0;i<s.size();i++)
	{
		if(s[i]>='0'&&s[i]<='9')
			i_z=(i_z*10)+(s[i]-'0');
		else return -1;
	}
	return i_z;
}
