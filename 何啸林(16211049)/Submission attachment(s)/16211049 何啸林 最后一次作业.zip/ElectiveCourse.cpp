#include "ElectiveCourse.h"
ElectiveCourse::ElectiveCourse() :grade('E')
{}
ElectiveCourse::ElectiveCourse(const string a,const int x) :grade('E')
{
	setname(a).setcreditHour(x);
}
ElectiveCourse::~ElectiveCourse()
{
}
ElectiveCourse& ElectiveCourse::setgrade(char c)
{
	if(c>='A'&&c<='E')
		grade=c;
	else if(c>='a'&&c<='e')
		grade=(c+'A'-'a');
	return *this;
}
int ElectiveCourse::getScore() const
{
	switch(grade)
	{
		case 'A':
			return 95;
			break;
		case 'B':
			return 85;
			break;
		case 'C':
			return 75;
			break;
		case 'D':
			return 65;
			break;
		case 'E':
			return 55;
			break;
		default :
			return 0;
			break;
	}
}
