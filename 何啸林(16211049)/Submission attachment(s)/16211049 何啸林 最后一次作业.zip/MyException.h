#ifndef MYEXCEPTION_H
#define MYEXCEPTION_H
#include<iostream>
using namespace std;
class MyException
{
	public:
		MyException();
		~MyException();
		static string DateExw;
		static string ChooseExw;
		static string InputExw;
};

#endif
