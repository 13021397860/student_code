#include "ObligatoryCourse.h"
#include<iostream>
using namespace std;
ObligatoryCourse::ObligatoryCourse() :mark(1)	
{}
ObligatoryCourse::ObligatoryCourse(const string a,const int x):mark(1)
{
	setname(a).setcreditHour(x);
}
ObligatoryCourse::~ObligatoryCourse()
{
}
ObligatoryCourse& ObligatoryCourse::setScore(int x)
{
	mark=x;
	return *this;
}
int ObligatoryCourse::getScore() const
{
	return mark;
}
