#include "Course.h"
#include<iostream>
using namespace std;
Course::Course()
{
	name="NULL";
	NumOfCourse++;
}
Course::Course(const Course &a)
{
	name=a.getname();
	creditHour=a.getcreditHour();
}
Course::Course(string a,int x)
{
	setname(a);
	setcreditHour(x);
	NumOfCourse++;
}
Course::~Course()
{
	NumOfCourse--;
}
Course& Course::setCourse(string a,int x)
{
	setname(a);setcreditHour(x);return *this;
}
Course& Course::setname(string a)
{
	name=a;return *this;
}
Course& Course::setcreditHour(int x)
{
	creditHour=x;
	return *this;
}
const string Course::getname() const
{
	return name;
}
int Course::getcreditHour() const
{
	return creditHour;
}
int Course::NumOfCourse=0;
int Course::getNumOfCourse()
{
	return NumOfCourse;
}
ostream& operator<<(ostream& out,const Course &a)
{
	out<<"courseName: "<<a.getname()<<", creditHour��"<<a.getcreditHour()<<", score: "<<a.getScore();
	return out;
}
