#include "Student.h"
#include"ObligatoryCourse.h"
#include"ElectiveCourse.h"
#define WeightOfObligatoryCourse 0.6
#define WeightOfElectiveCourse 0.4
#include<iostream>
#include<cstring>
#include<vector>
using namespace std;

int Student::count=0;
int Student::getcount()
{
	return count;
}
Student::Student() :courseNumber(0)
{
	name=new char[100];
	strcpy(name,"NULL");
	count+=1;
}
Student::Student(char*name_p,int y,int m,int d)
{
	name=new char[100];
	birthDate.setdate(y,m,d);
	strcpy(name,name_p);
	count+=1;
	courseNumber=0;
}
Student::Student(const Student &s1)
{
	name=new char[strlen(s1.name)+1]; 
	strcpy(name,s1.name);
	count+=1;
	birthDate=s1.birthDate;
	courseNumber=s1.courseNumber;
}
Student::~Student()
{
	if(name!=NULL)
		delete[] name;
	count-=1;
	while(courseNumber!=0){
		removeCourse(0);
	}
}
char* Student::getname() const
{
	return name;
}
void Student::setname(char* s)
{
	name=new char[strlen(s)+1]; 
	strcpy(name,s);
}
Date Student::getbirth() const
{
	return birthDate;
}
int Student::getcourseNumber() const
{
	return courseNumber;
}
Course& Student::getcourseList(int i) const 
{
	return *courseList[i];
}
void Student::printbirth() const
{
	cout<<birthDate;
}
Student& Student::setbirth(int y,int m,int d)
{
	birthDate.setdate(y,m,d);
	return *this;
}
Student& Student::setbirth(const Date& a)
{
	birthDate=a;
	return *this;
}
Student& Student::addCourse(Course* a)
{
	if(typeid(*a)==typeid(ElectiveCourse))
		courseList[courseNumber]=new ElectiveCourse(a->getname(),a->getcreditHour());
	else if(typeid(*a)==typeid(ObligatoryCourse))
		courseList[courseNumber]=new ObligatoryCourse(a->getname(),a->getcreditHour());
	else cout<<"WRONY!!!"<<endl;		//��ôŪ�� ������������ 
	courseNumber+=1;
	return *this;
}
bool Student::removeCourse(int x)
{
	if(x<0||x>=courseNumber) return false;
	delete courseList[x];
	for(int i=x;i<courseNumber-1;i++)
	{
		courseList[x]=courseList[x+1];
	}
	courseNumber--;
	return true;
}
ostream& operator<<(ostream& out,const Student &a)
{
	out<<"name: "<<a.getname()
	   <<" ,birthday: "<<a.getbirth()
	   <<", courselist is following: "<<endl;
	for(int i=0;i<a.getcourseNumber();i++)
	{
		out<<'\t'<<a.getcourseList(i)<<endl;
	}
	return out;
}
double Student::calcCredit() const
{
	int OgradeAndCredit=0,OAllCredit=0;
	int EAllGrade=0,ENum=0;
	double a,b,Calc=0;
	for(int i=0;i<courseNumber;i++)
	{
		if(typeid(*courseList[i])==typeid(ObligatoryCourse))
		{
			a=courseList[i]->getcreditHour();
			b=courseList[i]->getScore();
			OgradeAndCredit+=(a*b);
			OAllCredit+=a;
		}
		else
		{
			EAllGrade+=courseList[i]->getScore();
			ENum++;
		}
	}
	if(OAllCredit) Calc+=WeightOfObligatoryCourse*(OgradeAndCredit/OAllCredit);
	if(ENum) Calc+=WeightOfElectiveCourse*(EAllGrade/ENum);
	return Calc;
}
