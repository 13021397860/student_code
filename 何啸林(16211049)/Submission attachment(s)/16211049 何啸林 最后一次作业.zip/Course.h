#ifndef COURSE_H
#define COURSE_H
#define MAX_SIZE 100
#include<iostream>
using namespace std;
class Course
{
	public:
		Course();
		Course(const Course&);
		Course(string,int);
		virtual ~Course();
		Course& setCourse(string="NULL",int=0);
		Course& setname(string);
		Course& setcreditHour(int=0);
		const string getname() const;
		int getcreditHour() const;
		static int NumOfCourse;
		static int getNumOfCourse();
		friend ostream& operator<<(ostream&,const Course&);
		virtual int getScore() const =0;
	protected:
	private:
		string name;
		int creditHour; 
};

#endif
