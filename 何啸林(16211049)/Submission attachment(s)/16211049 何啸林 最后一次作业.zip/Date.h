#ifndef DATE_H
#define DATE_H
#include<fstream>
#include"MyException.h"
#include"DateEx.h"
using namespace std;
class Date
{
	public:
		Date();
		Date(int,int,int);
		~Date();
		Date(const Date&); 
		bool IsleapYear() const;
		Date& nextDay();
		Date& setyear(int );
		Date& setmonth(int );
		Date& setday(int );
		Date& setdate(int,int,int);
		int getyear() const;
		int getmonth() const;
		int getday() const;
		Date& operator++();
		Date& operator++(int);
		Date& operator+(int);
		friend istream& operator>>(istream &,Date&);
		friend ostream& operator<<(ostream &,const Date&);
		bool checkleg() const;
	protected:
	private:
		int year;
		int month;
		int day;
};

#endif
