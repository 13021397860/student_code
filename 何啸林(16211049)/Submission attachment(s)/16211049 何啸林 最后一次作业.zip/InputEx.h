#ifndef INPUTEX_H
#define INPUTEX_H
#include"MyException.h"
class InputEx
{
	public:
		InputEx();
		~InputEx();
};

#endif
