#ifndef DATEEX_H
#define DATEEX_H
#include"MyException.h"
class DateEx :public MyException
{
	public:
		DateEx();
		~DateEx();
};

#endif
