#include "Student.h"
#include "operation.h"
#include<iostream>
#include<iomanip>
#include<ctime>
#include<cstdlib>
#include<cstdio>
#include<cstring>
using namespace std;
int main()
{
    operation b;
    b.mainoperation();
}
