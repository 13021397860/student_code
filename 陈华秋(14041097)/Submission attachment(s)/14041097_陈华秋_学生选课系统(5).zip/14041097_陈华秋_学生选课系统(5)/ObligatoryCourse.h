#ifndef OBLIGATORYCOURSE_H
#define OBLIGATORYCOURSE_H
#include<string>
#include"Course.h"
class ObligatoryCourse:public Course
{
	public:
		ObligatoryCourse();
		ObligatoryCourse(string n1,int c1);
		string toString() const;
		void setmark(int m);
		int getScore()const;
		int getcreditHour()const; 
	protected:
		int mark;
		
		
};

#endif
