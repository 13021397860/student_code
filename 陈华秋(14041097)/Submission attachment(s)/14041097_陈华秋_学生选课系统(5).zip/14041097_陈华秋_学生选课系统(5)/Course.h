#ifndef COURSE_H
#define COURSE_H
#include<iostream>
#include<string>
#include<sstream>
using namespace std;
class Course
{
	public:
	    Course();
	    
	    
	    virtual ~Course();
			
		Course(string na,int cre);
		
		void setcourse(string n,int c);
		
		//string getcourse();
		
		string tostring()const;
		
		virtual void setmark(int m);
		
	    virtual int getScore()const=0;
	    
	    virtual int getcreditHour()const=0;
	    
	    virtual	void setgrade(int g);
	    
	    virtual string toString() const{	
		stringstream sstr;
	    sstr<<"�γ���:  "<<name<<"  ѧ��:  "<<creditHour<<"  �ɼ��� "<<getScore();
    
	    return  sstr.str();}
	    
	    friend ostream& operator << (ostream& out, const Course& c){
        out<<c.toString();
        return out;  
        
        }
        
    

		
	protected:
		string name;
		
		int creditHour;
		
		
};

#endif
