#ifndef CONSOLE_H
#define CONSOLE_H

class Console
{
	public:
	    
        //����Ϊ�쳣�������� �Զ��岻ͬ�����MyException�쳣�� 
		
		class MyException1{
		public:
	
		MyException1();
		
		
		const char* what() const;

		
		private:
			const char* message;
		
        };
		
		class MyException2{
		public:
	
		MyException2();
		
		const char* what() const;
		
		
		private:
            const char *message; 

        };
        
        class MyException3{
		public:
	
		MyException3();
		
		const char* what() const;
		
		
		private:
            const char *message; 

        };
		
		void run();
	protected:
};

#endif
