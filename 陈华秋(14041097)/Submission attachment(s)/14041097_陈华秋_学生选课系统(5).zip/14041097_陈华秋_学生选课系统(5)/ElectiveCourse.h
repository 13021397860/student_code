#ifndef ELECTIVECOURSE_H
#define ELECTIVECOURSE_H
#include"Course.h"
#include<string>
class ElectiveCourse:public Course
{
	public:
		
		ElectiveCourse(string n2,int c2);
		void setgrade(int g);
		int getScore()const;
		string toString() const;
		int getcreditHour()const;
		
	protected:
		char grade;
		
};

#endif
