#include "ObligatoryCourse.h"
#include<string>
#include<sstream>
#include"Console.h"
#include<exception>
#include<stdexcept> 
	ObligatoryCourse::ObligatoryCourse(){
		
	}
ObligatoryCourse::ObligatoryCourse(string n1,int c1){
	setcourse(n1,c1);

}

void ObligatoryCourse::setmark(int m){
	if(m>100||m<0){
		
		throw Console::MyException3();
	}
	mark=m;
} 

int ObligatoryCourse::getScore()const{
	
	return mark;
}

int ObligatoryCourse::getcreditHour()const{
	
	return creditHour;
}

string ObligatoryCourse::toString() const{

stringstream sstr;
	sstr<<"�γ���:  "<<name<<"  ѧ��:  "<<creditHour<<"  �ɼ��� "<<getScore();
    
	return  sstr.str();



}
