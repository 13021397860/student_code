#include<iostream>
#ifndef STUDET_H
#define STUDET_H
#include"Date.h"
#define MAX_SIZE 100
#include"Student.h"
#include"Course.h"
#include<string>
#include<sstream>
#include<fstream>
#include<stdio.h>
using namespace std;
class Student
{
	public:
		Student();
		 
		Student(char* s,Date birthDay,int Limit);
		
		Student(const Student &a);
		
		virtual ~Student();
		
		void print();   

		bool setName(char* s);  
		
	    char* getName();
	    
	    Date getBirthDate();
		
		int getcount();
		
	    Student& addCourse(Course *course);
			
		Course *courseList[MAX_SIZE];
		
        Student& addCourse(const string &courseName, int creditHour);
        	
		int getcourseNumber()const;
		
		bool removeCourse(int i); 
	
	     double calcCredit ()const;
		
		//����Ϊ����ѧ�������������� 
		friend ostream& operator << (ostream& out,const Student& s){
        
    out<<"������ "<<s.name<<"        �������ڣ� "<<s.birthDate.tostring()<<"     ѡ����Ϣ���£� \n";//ת��Ϊ�ַ���
    for(int i=1;i<=s.getcourseNumber();i++){
    	out<<(*s.courseList[i])<<"\n";
    	
    	
    	
	}
        out<<"��ѧ���ļ���ѧ��Ϊ�� "<<s.calcCredit()<<endl;
        return out;  
        
        }
		
	protected:
	private:
		char *name;
		
		Date birthDate;
		
		int limit;
		
		int num;
		
	    static int count;
	    
		bool isLegal(int n);
		
	
		 
		int courseNumber;
};

#endif

