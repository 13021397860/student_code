#include "ElectiveCourse.h"
#include"Console.h"
#include<string>
#include<iostream>
#include<sstream>
#include<exception>
#include<stdexcept> 
using namespace std;
ElectiveCourse::ElectiveCourse(string n2,int c2){
	setcourse(n2,c2);
}

void ElectiveCourse::setgrade(int g){
	
	if(g>100||g<0){
		
		throw Console::MyException3();
	}
	else if(g>=95)
	 {grade='A';
	 }
	else if(g>=85)
	 {grade='B';
	 }
	else if(g>=75)
	 {grade='C';
	 }
	 else	if(g>=65)
	 {grade='D';
	 }
	 else	if(g>=55)
	 {grade='E';
	 }
} 



int ElectiveCourse::getScore()const{
	if(grade=='A'){
		return 95;
	}
	if(grade=='B'){
		return 85;
	}
	if(grade=='C'){
		return 75;
	}
	if(grade=='D'){
		return 65;
	}
	if(grade=='E'){
		return 55;
	}
	
	
}

int ElectiveCourse::getcreditHour()const{
	
	return creditHour;
	
}

string ElectiveCourse::toString() const{
stringstream sstr;
	sstr<<"�γ���:  "<<name<<"  ѧ��:  "<<creditHour<<"  �ɼ��� "<<getScore();
    
	return  sstr.str();



}
