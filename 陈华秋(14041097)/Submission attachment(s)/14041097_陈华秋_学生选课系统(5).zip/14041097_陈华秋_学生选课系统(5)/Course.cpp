#include "Course.h"


#include<iostream>
#include<sstream>

using namespace std;

Course::Course(){
	
}

Course::Course(string na,int cre ){
	
     setcourse(na,cre);
}

void Course::setcourse(string n,int c){
    if(name!=""){
    	name="";
	}
	
	
	name=n;
	creditHour=c;
}
/*
string Course::getcourse(){
	
	return tostring();
	
} 
*/

       void Course::setmark(int m){}
		
	     //int Course::getScore()const{} 
	    
	   	void  Course::setgrade(int g){} 
	    
	   

string Course::tostring()const{
	
	stringstream sstr;
	sstr<<"�γ���:  "<<name<<"  ѧ��:  "<<creditHour<<"  �ɼ��� "<<getScore();
    
	return  sstr.str();
	
}

Course::~Course()
{ }
