#include "Date.h"
#include<iostream>
#include<sstream>
#include"Console.h"
#include<exception>
#include<stdexcept> 
using namespace std;

Date::Date(){
	year=1900;
	month=1;
	day=1;
}

Date::Date(int y,int m,int d){
   setDate(y,m,d); 
}

Date::Date(const Date &d)
{
    year=d.year;
	month=d.month;
	day=d.day;
}

bool Date::setDate(int y,int m,int d){
	year=y;
	month=m;
	day=d;
	return checkDate();
}

bool Date::checkDate(){
    int flag=1;
    if(month<=0||month>12)
        flag=0;
    if(day>maxDay()||day<=0)
        flag=0;
    if(flag==0){
    	
    	throw Console::MyException1();
	}
    return flag;
}

int Date::maxDay(){
	    
	
		if(month==1||month==3||month==5||month==7||month==8||month==10||month==12)
		{
			return 31;
		}
		if(month==4||month==6||month==9||month==11){
			return 30;
		}
		if(month==2&&isLeapYear())
		  return 29;
		else
		  return 28;
		
		
	}
	
bool Date::isLeapYear(){
	if(year%4==0&&year%100!=0||year%400==0)
	return true;
	else
	return false;
	
	
}	
	
	int Date::getyear(){
		
		return year;
	}
	
	int Date::getday(){
		
		return day;
	}
	
	int Date::getmonth(){
		
		return month;
	}
	
void Date::nextDay(){
	day++;
	if(!checkDate()){
		day=1;
		month++;
		if(!checkDate()){
			month=1;
			year++;
			
		}
		
	}
	
}

string Date::tostring()const{
	stringstream ss;
    ss<<year<<'-'<<month<<'-'<<day;//ת��Ϊ�ַ���
	return ss.str();
}
	/*
void Date::print()const{
	
	cout<<year<<"-"<<month<<"-"<<day<<endl; 
	
}	
	*/
Date::~Date()
{ }

