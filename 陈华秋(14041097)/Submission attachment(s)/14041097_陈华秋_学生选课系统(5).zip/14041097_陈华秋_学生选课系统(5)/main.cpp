#include <iostream>
#include<string>
#include"Date.h"
#include"Course.h"
#include "Student.h"
#include"ObligatoryCourse.h"
#include "ElectiveCourse.h"
#include "Console.h"
using namespace std;
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char** argv) {
	Console da;
	da.run();
	return 0;
}
