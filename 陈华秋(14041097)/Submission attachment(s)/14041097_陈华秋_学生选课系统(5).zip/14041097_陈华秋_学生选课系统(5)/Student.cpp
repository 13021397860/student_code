#include "Student.h"
#include<stdio.h>
#include"Date.h"
#include"ObligatoryCourse.h"
#include"ElectiveCourse.h"
#include<string>
#include<string.h>
#include <iostream>
using namespace std;

Student :: Student(){
   courseNumber=0;
}

int Student::count=0;


Student :: Student( char* s,Date birthDay,int Limit){//���캯����̬�����ڴ� 
  courseNumber=0;
  name=NULL;
  int n=strlen(s);
  num=n;

  name=new char[n+1];
  	
  birthDate=Date(birthDay);
  limit=Limit;
  if(setName(s)){
  
  
  	count++;
  
   }
}

Student::Student(const Student &a){
	courseNumber=0;
	int n=strlen(a.name);
	
    name=new char[n+1];
    strcpy(name,a.name);
	birthDate=a.birthDate;
	limit=a.limit;
	count++;


}

int Student::getcourseNumber()const{
	return courseNumber;
}

Student& Student::addCourse(Course* course){
	if(course!=NULL&&courseNumber<=100){
	
	courseNumber++;
	courseList[courseNumber]=course;

    }
}

double Student::calcCredit()const{
	
	int no1=0,no2=0;
	int ne1=0,ne2=0;
    double sum=0;
    for(int i=1;i<=getcourseNumber();i++){
    	
    	//sum+=courseList[i]->getScore();
    	if(dynamic_cast<ObligatoryCourse*>(courseList[i])!=NULL){
		     
		    ObligatoryCourse* obl;
			
		 	obl=dynamic_cast<ObligatoryCourse*>(courseList[i]);
			no1+=(obl->getScore())*(obl->getcreditHour());
			no2+=obl->getcreditHour();
		
		}
		if(dynamic_cast<ElectiveCourse*>(courseList[i])!=NULL){
			ElectiveCourse* ele;
		     
			 ele=dynamic_cast<ElectiveCourse*>(courseList[i]);
			 ne1+=ele->getScore();
			 ne2++;
		

		}
    	
    	
	}
	
	if(ne2!=0&&no2!=0){
		
	sum=0.6*no1/no2+0.4*ne1/ne2;
		
	}
	else if(ne2==0&&no2!=0){
		
		sum=0.6*no1/no2;
	}
	else{
		
		sum=0.4*ne1/ne2;
	}
	
    return sum;

}

bool Student:: isLegal(int n){//��nû��Ҫ�� ����Ҫ��n  nֻ��һ���β� 
	if(n>limit){
		printf("The name is too long! You have not created an object! \n");
		return 0;
	}
	if(n==0){
		printf("The name is empty ! You have not created an object! \n");
		return 0;
	}
	else
	return 1;
}

bool Student::setName( char* s) {
	strcpy(name,s);
    int n=strlen(s);
	return isLegal(n);
}

char* Student ::  getName(){
	return name;
}

Date Student:: getBirthDate(){
	return birthDate;
} 

int Student::getcount(){
	return count;
}

void Student::print(){
	
	printf("The name of the student is:   ");

    cout<<name<<endl;
	

	
	printf("The birthdate of the student is:   ");
	cout<<birthDate;
	
	
}

bool Student::removeCourse(int i){
	if(i>courseNumber&&courseNumber!=0||i<1){
		throw 	Console::MyException2();
		return false;
	}
	Course *c=courseList[i] ;
    delete c;//ɾ���γ�
    for(int j=i;j<courseNumber;j++){courseList[j] =courseList[j+1];
    }
    courseNumber--;
    return true;
	
}

Student:: ~Student(){//���������ͷ��ڴ� 
if(num<=limit&&name!=NULL){
	delete []name;
	//printf("the name has been destroyed ! \n");
}
}

