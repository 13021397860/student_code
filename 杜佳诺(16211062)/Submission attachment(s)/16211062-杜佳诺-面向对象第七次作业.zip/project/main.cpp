#include "interface.h"

int main()
{
    interface::fileText();
    Student stu=interface::createStudent();
    interface::CZ(stu);
}
