#ifndef MYDATEEXCEPTION_H
#define MYDATEEXCEPTION_H

#include <MyException.h>


class MyDateException : public MyException
{
    public:
        MyDateException();
        virtual ~MyDateException();

    protected:

    private:
};

#endif // MYDATEEXCEPTION_H
