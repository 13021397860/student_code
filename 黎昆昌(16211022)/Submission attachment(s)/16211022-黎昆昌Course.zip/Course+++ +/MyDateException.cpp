#include "MyDateException.h"

MyDateException::MyDateException()
{
    //ctor
}

MyDateException::~MyDateException()
{
    //dtor
}
