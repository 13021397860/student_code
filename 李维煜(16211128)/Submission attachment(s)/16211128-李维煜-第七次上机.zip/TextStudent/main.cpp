#include <iostream>
#include "Date.h"
#include "Course.h"
#include "ElectiveCourse.h"
#include "ObligatoryCourse.h"
#include "TextStudentClass.h"
#include"run.h"

using namespace std;

int main()
{

    run text1;
    text1.menu();
}
