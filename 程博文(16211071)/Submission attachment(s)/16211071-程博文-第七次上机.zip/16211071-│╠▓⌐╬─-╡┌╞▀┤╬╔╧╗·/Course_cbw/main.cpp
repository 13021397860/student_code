#include <iostream>
#include <string>
#include"Student.h"
#include"ObligatoryCourse.h"
#include"ElectiveCourse.h"
#include"Console.h"
using namespace std;


int main()
{
    Console test;
    test.Run();
    return 0;
}
