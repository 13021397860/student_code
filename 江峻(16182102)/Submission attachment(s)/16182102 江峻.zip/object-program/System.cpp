//
// Created by jj on 17-4-25.
//

#include <iostream>
#include <fstream>
#include <cstdlib>
#include "System.h"
#include "ObligatoryCourse.h"
#include "ElectiveCourse.h"
using namespace std;

bool System::loading() {
    system("clear");
    printf("Loading Course Information...\n");
    fstream courselist;
    courselist.open("courselist.txt");
    if(courselist.is_open())
        printf("Load Course Information Successful\n");
    else{
        printf("Load Course Information Fail, Is \"courselist.txt\" exist?");
        return 0;
    }
    char *a=new char[100];
    while(courselist.peek()!=EOF){
        courselist.getline(a,100,'\n');
        if(a[0]=='1'){
            cou[System::coursenum]=new ObligatoryCourse;
            courselist.getline(a,100,'\n');
            cou[System::coursenum]->setName(a);
            courselist.getline(a,100,'\n');
            int sum=0;
            for(int i=0;a[i]!='\0';i++){
                sum=sum*10+a[i]-48;
            }
            cou[System::coursenum]->setCreditHour(sum);
            System::coursenum++;
        }
        else if(a[0]=='2'){
            cou[System::coursenum]=new ElectiveCourse;
            courselist.getline(a,100,'\n');
            cou[System::coursenum]->setName(a);
            courselist.getline(a,100,'\n');
            int sum=0;
            for(int i=0;a[i]!='\0';i++){
                sum=sum*10+a[i]-48;
            }
            cou[System::coursenum]->setCreditHour(sum);
            System::coursenum++;
        }
    }
    return 1;
}

int System::login() {
    system("clear");
    char n1='3';
    int n=n1-48;
    while(n!=1&&n!=2&&n!=0){
        printf("User type(1.student 2.teacher)or 0 to exit:");
        scanf("%c",&n1);
        n=n1-48;
        if(n!=1&&n!=2&&n!=0)
            cout<<"Wrong Input\n";
    }
    while(n==1){
        printf("1.Login\n");
        printf("2.Sign in\n");
        printf("Please Input the Choice");
        char j1;
        int j=0;
        while (getchar () != '\n')
            continue;
        scanf("%c",&j1);
        j=j1-48;
        if(j==1){
            current=100;
            while(current>=Student::count){
                printf("Your Student Number:");
                scanf("%d",&current);
                current--;
            }
            break;
        }
        else if(j==2){
            printf("Your Student Number is %d\n",Student::count+1);
            current=Student::count;
            stu[current]=new Student;
            printf("Your Name:");
            char *name=new char;
            scanf("%s",name);
            printf("Your Birthday(example:2000 1 1):");
            int y,m,d;
            scanf("%d%d%d",&y,&m,&d);
            stu[current]->setName(name);
            stu[current]->setBirthDate(y,m,d);
            delete [] name;
            break;
        }
        else{
            cout<<"Wrong Input\n";
        }
    }
    while(n==2){
        current=100;
        while(current>=Student::count){
            printf("Number of the Student:");
            scanf("%d",&current);
            current--;
            if(current>=Student::count)
                cout<<"Student Whose Number is "<<current<<" isn't exist\n";
        }
        break;
    }
    return n;
}

void System::operate(int m) {
    int n;
    if(m==1){
        while(1){
            n=0;
            char n1;
            system("clear");
            printf("1.Query Students Information\n");
            printf("2.Add Course\n");
            printf("3.Delete Course\n");
            printf("4.Logout\n");
            printf("Please input the number:");
            while (getchar () != '\n')
                continue;
            scanf("%c",&n1);
            n=n1-48;
            if(n==1){
                system("clear");
                cout<<*stu[current];
                n=0;
                while(n!=1){
                    printf("1.Back to Last Menu\n");
                    printf("Please input the number:");
                    while (getchar () != '\n')
                        continue;
                    scanf("%c",&n1);
                    n=n1-48;
                    if(n!=1)
                        cout<<"Wrong Input\n";
                }
            }
            else if(n==2){
                while(1){
                    system("clear");
                    for(int i=0;i<System::coursenum;i++){
                        if(dynamic_cast<ObligatoryCourse*>(cou[i])!=NULL)
                            cout<<i+1<<"ObligatoryCourse ";
                        else
                            cout<<i+1<<"ElectiveCourse ";
                        cout<<*cou[i]->getName()<<' '<<cou[i]->getCreditHour()<<endl;
                    }
                    printf("0.Back to Last Menu\n");
                    printf("Please input the number:");
                    while (getchar () != '\n')
                        continue;
                    scanf("%c",&n1);
                    n=n1-48;
                    if(n==0){
                        break;
                    }
                    else if(n>0&&n<coursenum){
                        stu[current]->addCourse(cou[n]);
                    }
                    else
                        cout<<"Wrong Input\n";
                }
            }
            else if(n==3){
                system("clear");
                cout<<*stu[current];
                printf("0.Back to Last Menu\n");
                printf("Please Input the Course Number You Want to Delete:");
                while (getchar () != '\n')
                    continue;
                scanf("%c",&n1);
                n=n1-48;
                if(n!=0)
                    stu[current]->removeCourse(n);
                n=-1;
            }
            else if(n==4)
                break;
            else
                cout<<"Wrong Input\n";
        }
    }
    else if(m==2){
        n=0;
        while(1){
            char n1;
            system("clear");
            printf("1.Query Students Information\n");
            printf("2.Add Mark\n");
            printf("3.Save Information\n");
            printf("4.Exit\n");
            printf("Please input the number:");
            while (getchar () != '\n')
                continue;
            scanf("%c",&n1);
            n=n1-48;
            if(n==1){
                system("clear");
                printf("Current Student Information:\n");
                cout<<*stu[current];
                n=0;
                while(true){
                    printf("Input the Student Number to Query Other Student or 0 Back to Last Menu\n");
                    printf("Please input the number:");
                    while (getchar () != '\n')
                        continue;
                    scanf("%c",&n1);
                    n=n1-48;
                    if(n!=0&&n<Student::count&&n>=0){
                        printf("Student Information for %d:\n",n);
                        cout<<*stu[n-1];
                    }
                    else if(n==0)
                        break;
                    else
                        cout<<"Student Whose Number is "<<n<<" isn't exist\n";
                }
            }
            else if(n==2){
                system("clear");
                cout<<*stu[current];
                printf("0.Back to Last Menu\n");
                printf("Please Input the Course Number You Want to Add the Mark:");
                while (getchar () != '\n')
                    continue;
                scanf("%c",&n1);
                n=n1-48;
                if(n!=0){
                    printf("Please Input the Mark:");
                    int score;
                    scanf("%d",&score);
                    stu[current]->addCourseScore(n-1,score);
                }
            }
            else if(n==3){
                system("rm studentinformation.txt");
                system("touch studentinformation.txt");
                ofstream student("studentinformation.txt",ios::out|ios::app);
                for(int i=0;i<Student::count;i++){
                    student<<*stu[i];
                }
            }
            else if(n==4)
                break;
            else
                cout<<"Wrong Input\n";
        }
    }
    while (getchar () != '\n')
        continue;
}