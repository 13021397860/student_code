#include <iostream>
#include "Student.h"
#include "System.h"
#include "MyException.h"
using namespace std;

int Student::count=0;
int System::coursenum=0;

int main() {
    int n;
    System sys;
    if(sys.loading()){
        while(1){
            try {
                n=sys.login();
            }catch (MyException& e){
                char *m=new char;
                e.getMessage(m);
                cout<<"Get an exception:\nClass is "<<e.getClass()<<"\ntype is "<<e.getType()<<"\nMessage is \""<<m<<"\""<<endl;
            }
            if(n==-1)
                break;
            try {
                sys.operate(n);
            }catch (MyException& e){
                char *m=new char;
                e.getMessage(m);
                cout<<"Get an exception:\nClass is "<<e.getClass()<<"\ntype is "<<e.getType()<<"\nMessage is \""<<m<<"\""<<endl;
            }
        }
    }
    return 0;
}