//
// Created by jj on 17-3-21.
//

#include "Student.h"
#include "ObligatoryCourse.h"
#include "ElectiveCourse.h"
#include <string.h>
#include <cstdio>

Student::Student(const char *_name, const int _y, const int _m, const int _d) {
    name=new char[1];
    birthdate=new Date;
    setName(_name);
    setBirthDate(_y,_m,_d);
    count++;
}

Student::Student(const string *_name, const Date *_birthday) : Student(_name->c_str(),_birthday->getYear(),_birthday->getMonth(),_birthday->getDay()) {}

Student::Student(const char *_name, const Date *_birthday) : Student(_name,_birthday->getYear(),_birthday->getMonth(),_birthday->getDay()) {}

Student::Student(const string *_name, const int _y, const int _m, const int _d) : Student(_name->c_str(),_y,_m,_d) {}

Student::Student():Student("NULL",2000,1,1){}

Student::Student(Student *_s):Student(_s->name,_s->birthdate){}



Student::~Student() {
    delete [] name;
    count--;
}



int Student::setName(const char _a[]) {
    delete [] name;
    if(_a==NULL){
        printf("Error:name ptr is null");
        return 0;
    }
    else{
        size= strlen(_a);
        name=new char[size+1];
        strcpy(name,_a);
        return size;
    }
}

int Student::setName(const string *_a) {
    delete [] name;
    if(_a->length()==0){
        printf("Error:length of name is 0");
        return 0;
    }
    else{
        size= _a->length();
        name=new char[size+1];
        strcpy(name,_a->c_str());
        return size;
    }
}



void Student::getName(char *_a) {
    strcpy(_a,name);
}



bool Student::setBirthDate(const Date _birthday) {
    delete birthdate;
    birthdate=new Date(_birthday);
}

bool Student::setBirthDate(const int _y, const int _m, const int _d) {
    Date birthday(_y,_m,_d);
    setBirthDate(birthday);
}


Date Student::getBirthDate() {
    return birthdate;
}



Student& Student::addCourse(Course *_course) {
    if(dynamic_cast<ObligatoryCourse*>(_course)==NULL)
        courseList[courseNumber]=new ElectiveCourse(*_course);
    else
        courseList[courseNumber]=new ObligatoryCourse(*_course);
    courseNumber++;
    return *this;
}



bool Student::addCourseScore(int _coursenum,int _score) {
    ObligatoryCourse *tmp1;
    ElectiveCourse *tmp2;
    if(dynamic_cast<ObligatoryCourse*>(courseList[_coursenum])==NULL){
        tmp2=dynamic_cast<ElectiveCourse*>(courseList[_coursenum]);
        tmp2->setMark(_score);
    }
    else{
        tmp1=dynamic_cast<ObligatoryCourse*>(courseList[_coursenum]);
        tmp1->setMark(_score);
    }
}



int Student::getCourseScore(int _coursenum) {
    return courseList[_coursenum]->getMark();
}



bool Student::removeCourse(int n) {
    delete courseList[n-1];
    for(int i=n-1;i<courseNumber-2;i++){
        courseList[i]=courseList[i+1];
    }
    courseNumber--;
}

//static_cast

double Student::calaCredit() const {
    int o1=0,o2=0,e1=0,e2=0;
    double sum=0;
    for(int i=0;i<courseNumber;i++){
        if(dynamic_cast<ObligatoryCourse*>(courseList[i])==NULL){
            ElectiveCourse *tmp;
            tmp=dynamic_cast<ElectiveCourse*>(courseList[i]);
            e1+=tmp->getMark()*tmp->getCreditHour();
            e2+=tmp->getCreditHour();
        }
        if(dynamic_cast<ElectiveCourse*>(courseList[i])==NULL){
            ObligatoryCourse *tmp;
            tmp=dynamic_cast<ObligatoryCourse*>(courseList[i]);
            o1+=tmp->getMark()*tmp->getCreditHour();
            o2+=tmp->getCreditHour();
        }
    }
    if(e2!=0&&o2!=0)
        sum=0.6*o1/o2+0.4*e1/e2;
    else if(e2==0&&o2!=0)
        sum=0.6*o1/o2;
    else if(e2!=0&&o2==0)
        sum=0.4*e1/e2;
    else
        sum=0;
    return sum;
}



ostream& operator <<(ostream& out,const Student& _Student){
    out<<"Name:"<<_Student.name<<" "<<"Birthday:"<<*_Student.birthdate<<' '<<"Course Information:"<<endl;
    for(int i=0;i<_Student.courseNumber;i++){
        out<<*_Student.courseList[i]<<endl;
    }
    out<<"Credit:"<<_Student.calaCredit()<<endl;
    return out;
}