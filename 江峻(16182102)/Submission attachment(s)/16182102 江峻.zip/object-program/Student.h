//
// Created by jj on 17-3-21.
//

#ifndef OBJECT_PROGRAM_STUDENT_H
#define OBJECT_PROGRAM_STUDENT_H

#include "Date.h"
#include "Course.h"
#define MAX_SIZE 20

class Student {
protected:
    char *name;
    int size;
    Date *birthdate;
    Course *courseList[MAX_SIZE];
    int courseNumber;
public:
    static int count;
    Student();
    Student(const char *,const Date *);
    Student(const string *,const Date *);
    Student(const char *,const int,const int,const int);
    Student(const string *,const int,const int,const int);
    Student(Student *s);
    ~Student();
    int setName(const char *);
    int setName(const string *);
    void getName(char *);
    bool setBirthDate(const Date);
    bool setBirthDate(const int,const int,const int);
    Date getBirthDate();
    Student& addCourse(Course *course);
    bool addCourseScore(int,int);
    int getCourseScore(int);
    bool removeCourse(int);
    double calaCredit() const;
    friend ostream& operator <<(ostream&,const Student&);
};


#endif //OBJECT_PROGRAM_STUDENT_H
