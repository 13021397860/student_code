//
// Created by jj on 17-4-10.
//

#include "DeckOfCards.h"

DeckOfCards::DeckOfCards() {
    for(int i=0;i<4;i++){
        for(int j=0;j<13;j++){
            Card tmp(i,j);
            desk.push_back(tmp);
        }
    }
    currentCard=-1;
}

void DeckOfCards::shuffle() {
    srand(time(0));
    for(int i=0;i<52;i++){
        swap(desk[i],desk[rand()%52]);
    }
}

Card DeckOfCards::dealCard() {
    currentCard++;
    return desk[currentCard];
}

bool DeckOfCards::moreCard() {
    return currentCard<52;
}