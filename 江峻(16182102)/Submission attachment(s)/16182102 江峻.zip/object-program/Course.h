//
// Created by jj on 17-4-11.
//

#ifndef OBJECT_PROGRAM_COURSE_H
#define OBJECT_PROGRAM_COURSE_H

#include <string>
#include <iostream>
using namespace std;

class Course {
protected:
    string *name;
    int creditHour;
public:
    Course();
    Course(const Course&);
    Course(const string*,const int);
    Course(const char*,const int);
    virtual ~Course();
    int setName(const string*);
    int setName(const char*);
    string* getName() const;
    int setCreditHour(const int);
    int getCreditHour() const;
    virtual int getMark() const = 0;
    friend ostream& operator <<(ostream&,const Course&);
};


#endif //OBJECT_PROGRAM_COURSE_H
