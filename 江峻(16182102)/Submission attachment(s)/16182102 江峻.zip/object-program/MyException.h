//
// Created by jj on 2017/6/6.
//

#ifndef OBJECT_PROGRAM_MYEXCEPTION_H
#define OBJECT_PROGRAM_MYEXCEPTION_H


#include <exception>
using namespace std;

class MyException {
protected:
    int Class;
    int type;
    char* message;
public:
    MyException();
    MyException(int,int,char*);
    int getClass();
    int getType();
    void getMessage(char *);
};


#endif //OBJECT_PROGRAM_MYEXCEPTION_H
