//
// Created by jj on 17-4-11.
//

#include "ElectiveCourse.h"

ElectiveCourse::ElectiveCourse():Course(),grade('F') {}

ElectiveCourse::ElectiveCourse(const Course& _c):Course(_c),grade('F') {}

ElectiveCourse::ElectiveCourse(const string* _s,const int _n):Course(_s,_n),grade('F') {}

ElectiveCourse::ElectiveCourse(const char* _c,const int _n):Course(_c,_n),grade('F') {}

ElectiveCourse::~ElectiveCourse() {}



int ElectiveCourse::setMark(const int _mark) {
    if(_mark==95)
        grade='A';
    else if(_mark==85)
        grade='B';
    else if(_mark==75)
        grade='C';
    else if(_mark==65)
        grade='D';
    else if(_mark==55)
        grade='E';
    else {
        cout<<"Error Score,A=95,B=85,C=75,D=65,E=55";
        return 0;
    }
}



int ElectiveCourse::getMark() const{
    if(grade=='A')
        return 95;
    else if(grade=='B')
        return 85;
    else if(grade=='C')
        return 75;
    else if(grade=='D')
        return 65;
    else if(grade=='E')
        return 55;
    else
        return 0;
}