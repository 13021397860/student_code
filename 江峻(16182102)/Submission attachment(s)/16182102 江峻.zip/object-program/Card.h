//
// Created by jj on 17-4-10.
//

#ifndef OBJECT_PROGRAM_CARD_H
#define OBJECT_PROGRAM_CARD_H

#include <string>
using namespace std;

class Card {
protected:
    int face;
    int suit;
    static const string Face[4];
    static const string Suit[13];
public:
    Card(int,int);
    string toString();
};


#endif //OBJECT_PROGRAM_CARD_H
