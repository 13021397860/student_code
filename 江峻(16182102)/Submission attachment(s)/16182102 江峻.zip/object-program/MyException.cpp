//
// Created by jj on 2017/6/6.
//

#include "MyException.h"
#include <cstring>

MyException::MyException(int _Class, int _type, char *_message) {
    Class=_Class;
    type=_type;
    message=new char[strlen(_message)+1];
    strcpy(message,_message);
}
MyException::MyException() : MyException(0,0,"NULL") {}
int MyException::getClass() {
    return Class;
}
int MyException::getType() {
    return type;
}
void MyException::getMessage(char *e) {
    delete e;
    e=new char[strlen(message)+1];
    strcpy(e,message);
}