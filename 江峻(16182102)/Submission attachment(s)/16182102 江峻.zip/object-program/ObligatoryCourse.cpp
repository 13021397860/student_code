//
// Created by jj on 17-4-18.
//

#include "ObligatoryCourse.h"

ObligatoryCourse::ObligatoryCourse() : Course(),mark(0) {}

ObligatoryCourse::ObligatoryCourse(const Course& _c) : Course(_c),mark(0) {}

ObligatoryCourse::ObligatoryCourse(const string* _s,const int _n) : Course(_s,_n),mark(0) {}

ObligatoryCourse::ObligatoryCourse(const char* _c,const int _n) : Course(_c,_n),mark(0) {}



void ObligatoryCourse::setMark(const int _mark) {
    mark=_mark;
}



int ObligatoryCourse::getMark() const {
    return mark;
}


ObligatoryCourse::~ObligatoryCourse(){}