//
// Created by jj on 17-3-6.
//

#ifndef OBJECT_PROGRAM_DATE_H
#define OBJECT_PROGRAM_DATE_H

#include <iostream>
using namespace std;
class Date {
protected:
    bool isLegal(const int,const int);
    int year;
    int month;
    int day;
public:
    Date();
    Date(const Date *d);
    Date(const int,const int,const int);
    bool setYear(const int);
    int getYear() const;
    bool setMonth(const int);
    int getMonth() const;
    bool setDay(const int);
    int getDay() const;
    bool isLeapYear() const;
    void nextDay();
    void print() const;
    friend ostream& operator << (ostream& ,const Date&);
    Date operator ++(int);
    Date operator ++();
};



#endif //OBJECT_PROGRAM_DATE_H
