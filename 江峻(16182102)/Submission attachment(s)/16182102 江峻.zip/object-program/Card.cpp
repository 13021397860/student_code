//
// Created by jj on 17-4-10.
//

#include "Card.h"

Card::Card(int _face, int _suit) {
    face=_face;
    suit=_suit;
}

string Card::toString() {
    string tmp=Suit[suit]+" of "+Face[face];
    return tmp;
}