//
// Created by jj on 17-4-11.
//

#include "Course.h"
#include <iostream>
using namespace std;

Course::Course():Course("NULL",0){}

Course::Course(const Course &_course):Course(_course.name,_course.creditHour) {}

Course::Course(const string *_name, const int _creditHour) {
    name=new string;
    setName(_name);
    setCreditHour(_creditHour);
}

Course::Course(const char *_name, const int _creditHour) {
    name=new string;
    setName(_name);
    setCreditHour(_creditHour);
}

Course::~Course() {
    delete name;
}




int Course::setName(const string *_name) {
    if(_name->empty())
        return 0;
    delete name;
    name=new string(*_name);
    return name->length();
}

int Course::setName(const char *_name) {
    string tmp=_name;
    return setName(&tmp);
}




string* Course::getName() const {
    return name;
}




int Course::setCreditHour(int _creditHour) {
    if(creditHour>=0)
        creditHour=_creditHour;
    else
        return 0;
    return creditHour;
}




int Course::getCreditHour() const {
    return creditHour;
}



ostream& operator <<(ostream& out,const Course& _Course){
    out<<"Course Name:"<<*_Course.name<<' '<<"Credit:"<<_Course.creditHour<<' '<<"Score:"<<_Course.getMark();
    return out;
}
