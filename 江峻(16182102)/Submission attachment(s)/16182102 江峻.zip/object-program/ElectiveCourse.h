//
// Created by jj on 17-4-11.
//

#ifndef OBJECT_PROGRAM_ELECTIVECOURSE_H
#define OBJECT_PROGRAM_ELECTIVECOURSE_H

#include "Course.h"

class ElectiveCourse : public Course {
protected:
    char grade;
public:
    ElectiveCourse();
    ElectiveCourse(const Course&);
    ElectiveCourse(const string*,const int);
    ElectiveCourse(const char*,const int);
    virtual ~ElectiveCourse();
    int setMark(const int);
    int getMark() const;
};


#endif //OBJECT_PROGRAM_ELECTIVECOURSE_H
