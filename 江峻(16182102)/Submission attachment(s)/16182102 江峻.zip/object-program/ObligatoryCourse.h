//
// Created by jj on 17-4-18.
//

#ifndef OBJECT_PROGRAM_OBLIGATORYCOURSE_H
#define OBJECT_PROGRAM_OBLIGATORYCOURSE_H

#include "Course.h"

class ObligatoryCourse : public Course{
protected:
    int mark;
public:
    ObligatoryCourse();
    ObligatoryCourse(const Course&);
    ObligatoryCourse(const string*,const int);
    ObligatoryCourse(const char*,const int);
    ~ObligatoryCourse();
    void setMark(const int);
    int getMark() const;
};


#endif //OBJECT_PROGRAM_OBLIGATORYCOURSE_H
