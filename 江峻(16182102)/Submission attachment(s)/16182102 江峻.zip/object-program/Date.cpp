//
// Created by jj on 17-3-6.
//

#include "Date.h"
#include <cstdio>
#include "MyException.h"
#include <iostream>
using namespace std;

Date::Date(){
    year=2000;
    month=1;
    day=1;
}

Date::Date(const int y,const int m,const int d){
    year=2000;
    month=1;
    day=1;
    setYear(y);
    setMonth(m);
    setDay(d);
}

Date::Date(const Date *d){
    year=d->year;
    month=d->month;
    day=d->day;
}

bool Date::setYear(const int y){
    if(isLegal(y,0)){
        year=y;
        return true;
    }
    else{
        MyException e(1,1,"Year is wrong");
        throw e;
    }
    return false;
}

int Date::getYear() const{
    return year;
}

bool Date::setMonth(const int m){
    if(isLegal(m,1)){
        month=m;
        return true;
    }
    return false;
}

int Date::getMonth () const{
    return month;
}

bool Date::setDay(const int d){
    if(isLegal(d,2)){
        day=d;
        return true;
    }
    return false;
}

int Date::getDay() const{
    return day;
}

bool Date::isLeapYear() const{
    return year % 400 == 0 || (year % 4 == 0 && year % 100 != 0) || (year % 3200 == 0 && year % 172800 == 0);
}

void Date::nextDay(){
    if(month==12&&day==31){
        year+=1;
        month=1;
        day=1;
    }
    else if(month==1||month==3||month==5||month==7||month==8||month==10||month==12){
        if(day==31){
            day=1;
            month+=1;
        }
        else
            day+=1;
    }
    else if(month==2){
        if(isLeapYear()){
            if(day==28){
                day=1;
                month+=1;
            }
            else
                day+=1;
        }
        else{
            if(day==29){
                day=1;
                month+=1;
            }
            else
                day+=1;
        }
    }
    else{
        if(day==30){
            day=1;
            month+=1;
        }
        else
            day+=1;
    }
}

void Date::print() const{
    printf("%.4d-%.2d-%.2d\n",year,month,day);
}

bool Date::isLegal(const int n,const int m){
    if(m==0){
        if(n<0){
            printf("error:%.4d-%.2d-%.2d is illegal\n",n,month,day);
            return 0;
        }
    }
    else if(m==1){
        if(n<0||n>12){
            printf("error:%.4d-%.2d-%.2d is illegal\n",year,n,day);
            return 0;
        }
    }
    else if(m==2){
        if(n<=0){
            printf("error:%.4d-%.2d-%.2d is illegal\n", year, month, n);
            return 0;
        }
        else if(month==1||month==3||month==5||month==7||month==8||month==10||month==12) {
            if (n > 31) {
                printf("error:%.4d-%.2d-%.2d is illegal\n", year, month, n);
                return 0;
            }
        }
        else if(month==2) {
            if (isLeapYear()) {
                if (n > 28) {
                    printf("error:%.4d-%.2d-%.2d is illegal\n", year, month, n);
                    return 0;
                }
            }
        }
        else {
            if (n > 30) {
                printf("error:%.4d-%.2d-%.2d is illegal\n", year, month, n);
                return 0;
            }
        }
    }
    return 1;
}

ostream& operator << (ostream & out,const Date & _Date) {
    out<<_Date.year<<'-'<<_Date.month<<'-'<<_Date.day;
    return out;
}

Date Date::operator++(int) {
    this->nextDay();
    return *this;
}

Date Date::operator++() {
    Date tmp(*this);
    this->nextDay();
    return tmp;
}