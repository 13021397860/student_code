//
// Created by jj on 17-4-10.
//

#ifndef OBJECT_PROGRAM_DECKOFCARDS_H
#define OBJECT_PROGRAM_DECKOFCARDS_H

#include <vector>
#include "Card.h"
using namespace std;

class DeckOfCards {
protected:
    vector<Card> desk;
    int currentCard;
public:
    DeckOfCards();
    void shuffle();
    Card dealCard();
    bool moreCard();
};


#endif //OBJECT_PROGRAM_DECKOFCARDS_H
