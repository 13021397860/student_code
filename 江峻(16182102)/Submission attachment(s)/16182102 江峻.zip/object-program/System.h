//
// Created by jj on 17-4-25.
//

#ifndef OBJECT_PROGRAM_SYSTEM_H
#define OBJECT_PROGRAM_SYSTEM_H

#include "Student.h"

class System {
protected:
    Student *stu[100];
    Course *cou[100];
    int current;
    static int coursenum;
public:
    bool loading();
    int login();
    void operate(int);
};


#endif //OBJECT_PROGRAM_SYSTEM_H
