#include "Console.h"

int main()
{
    Console console;
    int result=console.run();
	return result;
}
