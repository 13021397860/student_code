#include"Student.h"
#include<string>
#include<fstream>
#include"myexception.h"
class show
{
public:
	string dodo;
	string name;
	Course * list[MAX_SIZE];
	int num = 0;
	int c;
	Student A;
	show()
	{
		ifstream ifs;
		ifs.open("courseinfo.txt", ios::in);
		int category, fee;
		string name;
		while (!ifs.eof())
		{
			ifs >> category >> name >> fee;
			if (category)
			{
				Course *a = new ObligatoryCourse(name, fee);
				list[num] = a;
				num++;
			}
			else
			{
				Course *a = new ElectiveCourse(name, fee);
				list[num] = a;
				num++;
			}
		}
		ifs.close();
	}
	void setS()
	{
		while (!A.birthday.setright)
		{
			try {
				int aa, ab, ac;
				string aaa;
				cin >> aaa >> aa >> ab >> ac;
				int s = cin.fail();
				while (s)
				{
					cin.clear();
					cin.ignore(1000, '\n');
					cout << "please input again:\n";
					cin >> aaa >> aa >> ab >> ac;
					s = cin.fail();
				}
				A.setStudent(aaa, aa, ab, ac);
			}
			catch (myexception& c)
			{
				cout << c.what();
			}
		}

	}
	void showinfo()
	{
		cout << "1.���ӱ��޿�\n2.����ѡ�޿�\n3.�鿴ѧ����Ϣ\n4.���óɼ�\n5.���ѧ����Ϣ\n6.ѡ��\n7.�鿴�γ��б�\n8.�˳�\n";
	}
	void insertOC()
	{
		cout << "����γ���Ϣ��";
		cin >> name >> c;
		int s = cin.fail();
		while (s)
		{
			cin.clear();
			cin.ignore(1000, '\n');
			cout << "please input again:\n";
			cin >> name >> c;
			s = cin.fail();
		}
		ofstream ofs;
		ofs.open("courseinfo.txt", ios::app);
		ofs <<'\n'<< 1 << ' ' << name << ' ' << c ;
		ofs.close();
		Course *a = new ObligatoryCourse(name, c);
		list[num] = a;
		num++;
	}
	void insertEC()
	{
		cout << "����γ���Ϣ��";
		cin >> name >> c;
		int s = cin.fail();
		while (s)
		{
			cin.clear();
			cin.ignore(1000, '\n');
			cout << "please input again:\n";
			cin >> name >> c;
			s = cin.fail();
		}
		ofstream ofs;
		ofs.open("courseinfo.txt", ios::app);
		ofs <<'\n'<< 0 << ' ' << name << ' ' << c;
		ofs.close();
		Course *a = new ElectiveCourse(name, c);
		list[num] = a;
		num++;
	}
	void setgrade()
	{
		int t;
		cin >> t;
		if (t > 0 && t <= A.courseNumber)
		{
			if (!(Course *)(A.courseList[t - 1])->charge)
			{
				char c;
				cin >> c;
				if (c >= 'A'&&c <= 'E')
					((ElectiveCourse *)A.courseList[t - 1])->setgrade(c);
				else
					cout << "wrong\n";
			}
			else
			{
				int c;
				cin >> c;
				int s = cin.fail();
				while (s)
				{
					cin.clear();
					cin.ignore(1000, '\n');
					cout << "please input again:\n";
					cin >> c;
					s = cin.fail();
				}
				((ObligatoryCourse *)A.courseList[t - 1])->setmark(c);
			}
		}
		else
		{
			throw myexception(2);
		}
	}
	void selectcourse()
	{
		cout << "������ѡ�γ̱��\n";
		cin >> c;
		int s = cin.fail();
		while (s)
		{
			cin.clear();
			cin.ignore(1000, '\n');
			cout << "please input again:\n";
			cin >> c;
			s = cin.fail();
		}
		if (c>0&&c<=num)
		{
			A.addCourse(list[c-1]);
		}
		else
		{
			throw myexception(2);
		}
	}
	void showw()
	{
		while (cin >> dodo&&num < MAX_SIZE)
		{
			if (dodo == "1")
			{
				insertOC();
			}
			else if (dodo == "2")
			{
				insertEC();
			}
			else if (dodo == "3")
			{
				cout << A << '\n';
			}
			else if (dodo == "4")
			{
				try
				{
					setgrade();
				}
				catch (myexception &c)
				{
					cout << c.what();
				}
			}
			else if (dodo == "5")
			{
				ofstream outfile("studentinfo.txt", ios::out);
				outfile << A;
				outfile.close();
			}
			else if (dodo == "6")
			{
				try {
					selectcourse();
				}
				catch (myexception &c)
				{
					cout << c.what();
				}
			}
			else if (dodo == "8")
				return;
			else if (dodo == "7")
			{
				cout << "�γ�����" << num << '\n';
				for (int i = 0; i < num; i++)
					cout <<i+1<< *list[i]<<'\n';
			}
			else
				cout << "\nWrong\n";
			showinfo();
		}
	}
	
	~show() {
		for (int i = 0; i < num; i++)
			delete list[i];
	}
};
int main()
{
	cout << "��װ����main������\nÿ��ֻ������һ�ſγɼ���ѡ�޿γɼ������ô�дA-E\n���óɼ���ʽ���γ̱��+�ո�+�ɼ�ֵ\n���ӿγ̸�ʽ���γ���+�ո�+ѧ��\n";
	cout << "������������";
	Date b(1, 1, 1);
	cout << b++ <<" "<< ++b << " "<<b + 100 << "\n";

	show a;
	cout << "���������ͳ������ڳ�ʼ��ѧ��\n";
	a.setS();
	a.showinfo();
	a.showw();


}