#include<iostream>
#include"myexception.h"
#include"Date.h"
using namespace std;
Date::Date(int y,int m, int d)
{
	setDate(y, m, d);
}
Date::Date()
{
}
void Date::setDate(int y,  int m, int d)
{
	if (m < 1 || m>12)
	{
		throw myexception(1);
	}
	else
	{
		if ((d > 31 || d < 1) && (m == 1 || m == 3 || m == 5 || m == 7 || m == 8 || m == 10 || m == 12))
			throw myexception(1);
		else if ((d > 30 || d < 1) && (m == 4 || m == 6 || m == 9 || m == 11))
			throw myexception(1);
		else if (m == 2 && isLeapYear(y) && (d > 29 || d < 1))
			throw myexception(1);
		else if (m == 2 && !isLeapYear(y) && (d > 28 || d < 1))
			throw myexception(1);
		else
		{
			year = y;
			month = m;
			day = d;
			setright = 1;
		}
	}
}
void Date::setYear(int y)
{
	year = y;
}
void Date::setMonth(int m)
{
	if (m > 12 || m < 1)
		cout << "month is out of range\n";
	else
		month = m;
}
void Date::setDay(int d)
{
	if ((d > 31 || d < 1) && (month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12))
		cout << "day is out of range\n";
	else if ((d > 30 || d < 1 )&& (month == 4 || month == 6 || month == 9 || month == 11))
		cout << "day is out of range\n";
	else if (month == 2 && isLeapYear(year) &&( d > 29 || d < 1))
		cout << "day is out of range\n";
	else if (month == 2 && !isLeapYear(year) && (d > 28 || d < 1))
		cout << "day is out of range\n";
	else
		day = d;
}
int Date::getYear() const
{
	return year;
}
int Date::getMonth() const
{
	return month;
}
int Date::getDay() const
{
	return day;
}
void Date::nextDay()
{
	if ( month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10)
	{
		day++;
		if (day == 32)
		{
			month++;
			day = 1;
		}
	}
	else if (month == 2 && isLeapYear())
	{
		day++;
		if (day == 30)
		{
			month++;
			day = 1;
		}
	}
	else if (month == 2 && !isLeapYear())
	{
		day++;
		if (day == 29)
		{
			month++;
			day = 1;
		}
	}
	else if (month == 12)
	{
		day++;
		if (day == 32)
		{
			year++;
			month = 1;
			day = 1;
		}
	}
	else
	{
		day++;
		if (day == 30)
		{
			month++;
			day = 1;
		}
	}
}
bool Date::isLeapYear() const
{
	if (year % 4 == 0 && year % 400 == 0)
		return true;
	else if (year % 4 == 0 && year % 100 != 0)
		return true;
	else
		return false;
}
bool Date::isLeapYear(int y)
{
	if (y % 4 == 0 && y % 400 == 0)
		return true;
	else if (y % 4 == 0 && y % 100 != 0)
		return true;
	else
		return false;
}
Date::Date(const Date& C)
{
	year = C.year;
	month = C.month;
	day = C.day;
}
Date::~Date()
{
}

ostream & operator<<(ostream & out, Date & C)
{
	out << C.getYear() << "-" << C.getMonth() << "-" << C.getDay();
	return out;
}
Date Date::operator++()
{
	nextDay();
	return *this;
}
Date Date::operator++(int)
{
	Date temp(*this);
	nextDay();
	return temp;
}
Date Date::operator + (int i)
{
	Date temp(*this);
	for (int j = 0; j < i; j++)
		temp.nextDay();
	return temp;
}