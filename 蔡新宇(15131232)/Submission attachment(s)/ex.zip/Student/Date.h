#pragma once
//Date class declaration
#ifndef DATE_H
#define DATE_H
#include<iostream>
using namespace std;
class Date
{
public:
	bool checkDate = 0;
	bool setright = 0;
	Date();
	Date(int, int, int);
	void setDate(int, int, int);
	void setYear(int);
	void setMonth(int);
	void setDay(int);
	int getYear() const;
	int getMonth() const;
	int getDay() const;
	void nextDay();
	bool isLeapYear() const;
	bool isLeapYear(int);
	Date(const Date& C);
	~Date();

	friend ostream &operator <<(ostream & out, Date & C);
	Date operator +(int);
	Date operator ++();
	Date operator ++(int);
private:
	int year=1900;
	 int month=1;
	int day=1;
};
#endif

