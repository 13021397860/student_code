#include"course.h"
#include<iostream>
#include"myexception.h"
using namespace std;
Course::Course() {}
Course::Course(string a, int b)
{
	name = a;
	creditHour = b;
}
void Course::setname(string a)
{
	name = a;
}
void Course::setcreditHour(int b)
{
	creditHour = b;
}
string Course::getname()
{
	return name;
}
int Course::getcreditHour()
{
	return creditHour;
}
Course::~Course() {};

ostream &operator <<(ostream & out, Course &C)
{
	out << "�γ�����" << C.name.c_str() << " ѧ�֣�" << C.creditHour;
	return out;
}

void ObligatoryCourse::setmark(int i)
{
	if (i < 0)
		throw myexception(3);
	else if (i > 100)
		throw myexception(3);
	else
		mark = i;
}
void Course::setgrade(char j){}
void Course::setmark(int i){}
int Course::getScore()
{
	return 0;
}
int ObligatoryCourse::getScore()
{
	return mark;
}
ObligatoryCourse::ObligatoryCourse(string a, int b)
{
	setname(a);
	setcreditHour(b);
	charge = 1;
}

ElectiveCourse::ElectiveCourse(string a, int b)
{
	setname(a);
	setcreditHour(b);
	charge = 0;
}

void ElectiveCourse::setgrade(char c)
{
	if (c >= 'A'&&c <= 'E')
		grade = c;
	else
		throw myexception(3);
}
int ElectiveCourse::getScore()
{
	if (grade == 'A')
		return 95;
	else if (grade == 'B')
		return 85;
	else if (grade == 'C')
		return 75;
	else if (grade == 'D')
		return 65;
	else
		throw myexception(3);
}