#pragma once
#ifndef MYEXCEPTION_H
#define MYEXCEPTION_H
#include<iostream>
#include<exception>
using namespace std;
class myexception :exception
{
public:
	myexception(int i)
	{
		errID = i;
	}
	const char* what() const throw()
	{
		switch (errID)
		{
		case 1:
			return "���ڴ���\n";
		case 2:
			return "�γ̷��ʴ���\n";
		case 3:
			return "�ɼ��Ƿ�\n";
		}
	}
private:
	int errID;
};
#endif
