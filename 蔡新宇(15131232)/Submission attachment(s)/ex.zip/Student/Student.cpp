#include"Student.h"
#pragma warning(disable:4996)
int Student::count = 0;

Student::Student()
{
}
Student::Student(string name, int y, int m, int d, int ID)
{
	if (name == "")
	{
		cout << "Wrong name!";
		birthday.setDate(y, m, d);
		if (birthday.checkDate)
			cout << "Wrong date!";
	}
	else
	{
		birthday.setDate(y, m, d);
		if (birthday.checkDate)
			cout << "Wrong date!";
		this->ID = ID;
		this->name = (char*)malloc(name.size() + 1);
		strcpy(this->name, name.c_str());
		check = 1;
		if (!birthday.checkDate)
			count++;
	}
}
Student::Student(const Student& C)
{
	string s;
	s = C.name;
	if (!check)
		this->name = (char*)malloc(s.size() + 1);
	strcpy(this->name, s.c_str());
	check = 1;
	birthday = C.birthday;
	ID = C.ID;
}
Student::~Student()
{
	free(name);
	cout << "Delete\n";
}

void Student::setStudent(string name, int y, int m, int d)
{
	birthday.setDate(y, m, d);
	this->name = (char*)malloc(name.size()+1);
	strcpy(this->name, name.c_str());
}
void Student::setStudentBirthday(int y, int m, int d)
{
	birthday.setDate(y, m, d);
	if (birthday.checkDate)
		cout << "Wrong Date\n";
}
void Student::setStudentName(string name)
{
	if (name == "")
		cout << "Wrong name\n";
	else
	{
		if (!check)
			this->name = (char*)malloc(name.size() + 1);
		check = 1;
		strcpy(this->name, name.c_str());
	}
}
void Student::setStudentID(int m)
{
	ID = m;
}

void Student::getStudent()
{
	if (birthday.checkDate)
		cout << "Wrong Info\n";
}
Date Student::getStudentBirthday()
{
	return birthday;
}
char* Student::getStudentName()
{
	return name;
}
int Student::getStudentID()
{
	return ID;
}

Student& Student::addCourse(Course *course)
{
	if (courseNumber >= MAX_SIZE)
	{
		cout << "Too many courses!\n";
		return *this;
	}
	else
	{
		courseList[courseNumber++] = course;
		return *this;
	}
}
Student& Student::addCourse(const string &courseName, int creditHour)
{
	if (courseNumber >= MAX_SIZE)
	{
		cout << "Too many courses!\n";
		return *this;
	}
	else
	{
		Course a(courseName, creditHour);
		courseList[courseNumber++] = &a;
		return *this;
	}
}

ostream &operator <<(ostream & out, Student & C)
{
	out << "������" << C.name << " �������ڣ�" << C.birthday << " ��ѡ����Ϣ���£�\n";
	for (int i = 0; i < C.courseNumber; i++)
		out << "\t" <<i+1<<"  "<< *(C.courseList[i]) <<" �ɼ���"<<C.courseList[i]->getScore()<< "\n";
	out <<"     GPA:   "<< C.calcCredit()<<"\n";
	return out;
}

bool Student::removeCourse(int i)
{
	if (i > 0 && i <= courseNumber&&courseNumber>0)
	{
		courseList[i-1] = NULL;
		for (int j = i; j < courseNumber; j++)
			courseList[j - 1] = courseList[j];
		courseNumber--;
		return true;
	}
	else
		return false;
}


float Student::calcCredit()
{
	float sum1;
	sum1 = 0;
	int sum2;
	sum2 = 0;
	for (int i = 0; i < courseNumber; i++)
	{
		if (courseList[i]->charge)
			sum1 += courseList[i]->creditHour;
		else
			sum2 += 1;
	}
	float gpa = 0;
	for (int i = 0; i < courseNumber; i++)
	{
		if (courseList[i]->charge)
			gpa += 0.6*courseList[i]->getScore()*courseList[i]->creditHour / sum1;
		else
			gpa += 0.4*courseList[i]->getScore() / sum2;
	}
	return gpa;
}

