#pragma once
#include"Date.h"
#include<iostream>
#include"course.h"
#ifndef STUDENT_H
#define STUDENT_H
#define MAX_SIZE 20
using namespace std;
class Student {
public:
	Date birthday;
	char *name;
	static int count;
	int ID;
	bool check=0;
	Course *courseList[MAX_SIZE];
	int courseNumber = 0;

	Student();
	Student(string, int, int, int, int);
	Student(const Student& C);
	~Student();

	void setStudent(string, int, int, int);
	void setStudentName(string);
	void setStudentID(int);
	void setStudentBirthday(int, int, int);

	void getStudent();
	char* getStudentName();
	int getStudentID();
	Date getStudentBirthday();

	float calcCredit();

	Student& addCourse(Course *course);
	Student& addCourse(const string &courseName, int creditHour);

	friend ostream &operator << (ostream & out, Student & C);

	bool removeCourse(int);
};
#endif