#pragma once
#ifndef COURSE_H
#define COURSE_H
#include<iostream>
using namespace std;
class Course
{
public:
	bool charge;
	string name;
	int creditHour;
	void setname(string);
	void setcreditHour(int);
	string getname();
	int getcreditHour();
	~Course();
	Course(string, int);
	Course();
	virtual void setmark(int);
	virtual int getScore();
	virtual void setgrade(char);

	friend ostream &operator<<(ostream & out, Course &C);
};


class ObligatoryCourse :public Course
{
private:
	int mark=0;

public:
	int getScore();
	void setmark(int);
	ObligatoryCourse(string, int);
};

class ElectiveCourse :public Course
{
private:
	char grade='E';
public:
	void setgrade(char);
	int getScore();
	ElectiveCourse(string, int);
};
#endif