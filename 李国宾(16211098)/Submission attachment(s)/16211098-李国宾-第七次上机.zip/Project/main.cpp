//main.cpp
#include"Console.h"

int main() {
	Console console;
	console.run();
}
