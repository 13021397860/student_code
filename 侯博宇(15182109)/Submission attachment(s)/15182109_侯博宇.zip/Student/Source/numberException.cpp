#include "numberException.h"


numberException::numberException(string s)
:MyException(s)
{

}


numberException::~numberException()
{
}
