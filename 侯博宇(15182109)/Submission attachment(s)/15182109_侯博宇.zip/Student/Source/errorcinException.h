#pragma once
#include "MyException.h"
class errorcinException :
	public MyException
{
public:
	errorcinException(string s);
	~errorcinException();
};

