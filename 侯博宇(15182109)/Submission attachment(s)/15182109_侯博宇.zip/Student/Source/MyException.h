#pragma once
#include "stdafx.h"
class MyException
{
public:
		
	MyException();
	~MyException();
	MyException(const string & right);
		
	string what() const{return message;}
private:
	string  message;
	
};

