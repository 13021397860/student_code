#include "ObligatoryCourse.h"


ObligatoryCourse::ObligatoryCourse(const string name, const int creditHour)
:Course(name,creditHour)
{
	mark = -1;
}

ObligatoryCourse::ObligatoryCourse(const  ObligatoryCourse& oc)
: Course(oc), mark(oc.mark)
{

}

ObligatoryCourse::~ObligatoryCourse()
{
	mark = -1;
}


int ObligatoryCourse::getScore() const
{
	return mark;
}


void ObligatoryCourse::setScore(int mk)
{
	mark = mk;
}

void ObligatoryCourse::destroyScore()
{
	mark = -1;
}