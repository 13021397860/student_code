#pragma once
#include "MyException.h"
class numberException :
	public MyException
{
public:
	numberException(string s);
	~numberException();
};

