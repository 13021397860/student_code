#pragma once
#include "stdafx.h"
#include "Student.h"
#include "Date.h"
#include "Course.h"
#include "ElectiveCourse.h"
#include "ObligatoryCourse.h"
class Console
{
public:
	int run();

	Console();  
	virtual ~Console();
private:
	int displayMenu() const;    
	Course* selectCourse(int op);

	bool setCourseScore(int i); 
	void setCourseScore();

	Console& buildStudent();
	Console& buildCourse();

	Console& buildOCourse();
	Console& buildECourse();

	Console& removeCourse();

	Course* addCourse(const string& courseName);

	Console& saveStudentInfor();
	Console& getStudentInfor(const string& studentName);
	Console& buildNewStudent(const string& StudentName);
	Console& confirmStudentInfor();

	Student *student;
	Course *oc[MAX_SIZE];
	Course *ec[MAX_SIZE];
	int ocNum;
	int ecNum;
};
