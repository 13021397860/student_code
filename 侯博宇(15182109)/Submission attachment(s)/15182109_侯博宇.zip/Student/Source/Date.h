#pragma once
#include "stdafx.h"
class Date
{
public:
	void nextDay();
	bool isLeapYear()const;

	void setDate(int y, int m, int d);
	int getYear()const; 
	int getMonth()const;
	int getDay()const; 

	Date();
	Date(int y, int m, int d);
	Date(const Date &d);
	virtual ~Date();

	 Date& operator ++();
	 Date& operator ++(int);
	 Date& operator +( int x);
	friend std::ostream & operator <<(std::ostream &os, const Date &d);
	friend std::istream & operator >>(std::istream &is, Date &d);
	bool checkDate();
protected:
private:
	int maxDay()const;

	int year;
	int month;
	int day;
};

