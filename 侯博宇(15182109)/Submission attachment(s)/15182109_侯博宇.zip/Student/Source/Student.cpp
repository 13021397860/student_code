#include "stdafx.h"
#include "student.h"
int Student::m_count = 0;
Student::Student()
:birthDate(1970, 1, 1)
{
	name = NULL; setName("����");
	++m_count;
}

Student::Student(const char *n, const Date &dateofbirth)
: birthDate(dateofbirth)
{
	name = NULL; setName(n);
	++m_count;
}

Student::Student(const char *n, int y, int m, int d)
: birthDate(y, m, d)
{
	name = NULL; setName(n);
	++m_count;
}

Student::Student(const Student &s)
:birthDate(s.birthDate)
{
	name = NULL; setName(s.name);
	++m_count;
}

Student::~Student()
{
	courseNumber = 0;
	delete[] name;
	--m_count;
}

Student& Student::setName(const char *n)
{
	if (name) delete[] name;
	length = strlen(n);
	name = new char[length + 1];
	strcpy_s(name, length + 1, n);
	return *this;
}

const char* Student::getName() const
{
	return name;
}

int Student::getCount()
{
	return m_count;
}

const Date Student::getbirthDay() const
{
	return birthDate;
}

Student& Student::addCourse(Course *course)
{
	if (courseNumber <= MAX_SIZE)
	{
		bool k = 0;
		for (int i = 0; i < courseNumber; i++)
		{
			if (existCourse(course)==true)
			{
				cout << "���Ѿ�ѡ�����ſ��ˣ���ѡ�������γ�" << endl;
				k = 1;
				break;
			}
		}
		if (k == 0)
		{
			courseList[courseNumber++] = course;
		}
	}
	return *this;
}

ostream& operator<<(ostream& output, const Student& s)
{
	if (typeid(output) == typeid(ofstream))
	{
		int flag = 0;
		output << s.name << " "
			<< s.birthDate << "\n";
		for (int i = 0; i < s.courseNumber; i++)
		{
			if (s[i].getScore() == -1)
			{
				output << s[i] << endl;
			}
			else
			{
				flag += 1;
				output << s[i] << " ";
				output << s[i].getScore() << endl;
			}
		}
		if ((flag == s.courseNumber)&&(s.courseNumber!=0))
		{
			output << s.calcAchievement() << endl;
		}
	}
	else
	{
		int flag = 0;
		output << "������" << s.name << "\t�������ڣ�" << s.birthDate << endl;
		for (int i = 0; i < s.courseNumber; i++)
		{
			if (s[i].getScore() == -1)
			{
				output << s[i];
			}
			else
			{
				flag += 1;
				output << s[i];
				output << "�ɼ���" << s[i].getScore() << endl;
			}
		}
		if (flag == s.courseNumber&&s.courseNumber!=0)
		{
			output << "\t����ɼ���" << s.calcAchievement() << endl;
		}
	}
	return output;
}

bool Student::removeCourse(int i)
{
	if (i < courseNumber)
	{
		courseList[i]->destroyScore();
		for (int j = i; j < courseNumber - 1; j++)
		{
			courseList[j] = courseList[j + 1];
		}
		courseNumber--;
		return true;
	}
	else{ return false; }
}

bool Student::removeCourse(const string& courseName)
{
	int i;
	for (i = 0; i < courseNumber; i++){
		if (courseName == courseList[i]->getName()) break;
	}if (i < courseNumber){
		return removeCourse(i);
	}else{
		return false;
	}
}

const Course& Student::operator[](int subscript) const
{
	if (subscript < 0 || subscript >= courseNumber)
	{
		cerr << "�±�Խ��: " << subscript << endl;
		exit(1);
	}
	return (*courseList[subscript]);
}

Course& Student::operator[](int subscript)
{
	if (subscript < 0 || subscript >= courseNumber)
	{
		cerr << "�±�Խ��: " << subscript << endl;
		exit(1);
	}
	return (*courseList[subscript]);
}

Course& Student::getCourse(int i)
{
	return *courseList[i];
}

Course& Student::getCourse(const string& courseName)
{
	int i;
	for (i = 0; i < courseNumber; i++){
		if (courseName == courseList[i]->getName()) break;
	}if (i < courseNumber){
		return *courseList[i];
	}
}

const int Student::getCourseNumber() const
{
	return courseNumber;
}

int Student::calcObligatoryCredit() const
{
	int totalCredit = 0;
	for (int i = 0; i < courseNumber; i++)
	{
		totalCredit += (*this)[i].getObligatoryCredit();
	}
	return totalCredit;
}

int Student::calcObligatoryNumber() const
{
	int number = 0;
	for (int i = 0; i < courseNumber; i++)
	{
		number += (*this)[i].getObligatoryNumber();
	}
	return number;
}

int Student::calcElectiveNumber() const
{
	int number = 0;
	for (int i = 0; i < courseNumber; i++)
	{
		number += (*this)[i].getElectiveNumber();
	}
	return number;
}


double Student::calcAchievement() const
{
	int obligatoryCredit = calcObligatoryCredit();//���޿���ѧ��
	int electiveNumber = calcElectiveNumber(); //ѡ�޿����Ŵ�
	int obligatoryNumber = calcObligatoryNumber();
	double result = 0;
	for (int i = 0; i < courseNumber; i++)
	{
		if (obligatoryNumber == 0)
		{
			result += (*this)[i].getScore()
				* (*this)[i].getElectiveNumber() / electiveNumber;
		}
		else if (electiveNumber == 0)
		{
			result += (*this)[i].getScore()
				* (*this)[i].getObligatoryCredit() / obligatoryCredit;
		}
		else
		{
			result += (*this)[i].getWeight() * (*this)[i].getScore()
				* (*this)[i].getElectiveNumber() / electiveNumber;

			result += (*this)[i].getWeight() * (*this)[i].getScore()
				* (*this)[i].getObligatoryCredit() / obligatoryCredit;
		}
	}
	return result;
}

bool Student::existCourse(Course *course)
{
	for (int i = 0; i < courseNumber; i++){
		if (courseList[i] == course) return true;
	}
	return false;
}