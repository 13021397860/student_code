//ѡ�޿���
#pragma once
#include "Course.h"
#include "stdafx.h"
class ElectiveCourse :
	public Course
{
public:
	ElectiveCourse(const string name, const int creditHour);//ѡ�޿�
	ElectiveCourse(const  ElectiveCourse& ec);
	~ElectiveCourse();
private:
	char mark;
public:
	virtual void destroyScore();
	void setScore(char mk);
	void setScore(int mk);
	virtual int getScore() const;
	virtual double getWeight() const { return 0.4; }
	virtual int getObligatoryCredit() const { return 0; }

};

