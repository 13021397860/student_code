#include "MyException.h"


MyException::MyException()
{
	message = "";
}


MyException::~MyException()
{}

MyException::MyException(const string & right)
{
	message = right;
}