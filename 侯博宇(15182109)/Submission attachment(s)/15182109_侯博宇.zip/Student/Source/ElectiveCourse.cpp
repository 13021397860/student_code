#include "ElectiveCourse.h"


ElectiveCourse::ElectiveCourse(const string name, const int creditHour)
:Course(name,creditHour)
{
	mark = -1;
}

ElectiveCourse::ElectiveCourse(const  ElectiveCourse& ec)
: Course(ec), mark(ec.mark)
{
	
}

ElectiveCourse::~ElectiveCourse()
{
	mark = -1;
}

int ElectiveCourse::getScore()const
{
	switch (mark)
	{
	case 'A':
		return 95;
		break;
	case 'B':
		return 85;
		break;
	case 'C':
		return 75;
		break;
	case 'D':
		return 65;
		break;
	case 'E':
		return 55;
		break;
	default:
		return -1;
		break;
	}
	
}

void ElectiveCourse::setScore(char mk)
{
	mark = mk;
}

void ElectiveCourse::setScore(int mk)
{
	switch (mk)
	{
	case 95:
		mark = 'A';
		break;
	case 85:
		mark = 'B';
		break;
	case 75:
		mark = 'C';
		break;
	case 65:
		mark = 'D';
		break;
	case 55:
		mark = 'E';
		break;
	default:
		mark = -1 ;
		break;
	}
}

void ElectiveCourse::destroyScore()
{
	mark = -1;
}