#include "stdafx.h"
#include "Course.h"
Course::Course()
{}
Course::Course(const string n,const int ch)
:name(n), creditHour(ch){}

Course::~Course()
{

}
string Course::getName()const
{
	return name;
}
int Course::getCreditHour()const
{
	return creditHour;
}

Course& Course::setName(const string n)
{
	name = n;
	return *this;
}
Course& Course::setCreditHour(const int ch)
{
	creditHour = ch;
	return *this;
}

ostream & operator <<(ostream &os, const Course &c)
{
	if (typeid(os) == typeid(ofstream))
	{
		os << c.name << " "
			<< c.creditHour << " ";
	}
	else
	{
		os << "�γ�����" << c.name << " ѧ�֣�" << setw(2) << c.creditHour << " " << endl;
	}
	return os;
}