//���޿���
#pragma once
#include "Course.h"
#include "stdafx.h"
class ObligatoryCourse :
	public Course
{
public:
	//�������޿�
	ObligatoryCourse(const string name, const int creditHour);
	ObligatoryCourse(const  ObligatoryCourse& oc);
	~ObligatoryCourse();
private:
	int mark;
public:
	virtual void destroyScore();
	void setScore(int);
	virtual int getScore() const;
	virtual double getWeight() const { return 0.6; }
	virtual int getElectiveNumber() const { return 0; }

};

