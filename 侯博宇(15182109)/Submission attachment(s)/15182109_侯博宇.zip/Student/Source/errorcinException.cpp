#include "errorcinException.h"


errorcinException::errorcinException(string s)
:MyException(s)
{
}


errorcinException::~errorcinException()
{
}
