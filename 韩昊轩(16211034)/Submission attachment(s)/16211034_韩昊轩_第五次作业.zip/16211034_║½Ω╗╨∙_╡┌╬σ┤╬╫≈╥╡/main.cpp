#include <iostream>
#include"Course.h"
#include"Student.h"
#include"ObligatoryCourse.h"
#include"ElectiveCourse.h"
#include<string>
#include<cstdio>
#include<iomanip>
#include"Console.h"
using namespace std;

int main()
{
    Console con;
    con.run();
    return 0;
}
