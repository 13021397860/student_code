#include <iostream>
#include "console.h"
using namespace std;

int main()
{
    console console;
    int result=console.run();
    return result;
}

/*
 * 成绩默认设置为0或E
 */