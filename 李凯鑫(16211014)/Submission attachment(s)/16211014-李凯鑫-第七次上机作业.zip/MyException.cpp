#include "MyException.h"

MyException::MyException()
{
    //ctor

}

MyException::~MyException()
{
    //dtor
}
