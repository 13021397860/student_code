
#include "Console.h"

using namespace std;

int main()
{
    //ios::sync_with_stdio(false);
    Console console;
    console.run();
}
