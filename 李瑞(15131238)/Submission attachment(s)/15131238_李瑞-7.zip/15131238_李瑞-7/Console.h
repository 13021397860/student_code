#ifndef CONSOLE_H
#define CONSOLE_H

#include<iostream>
#include<string>
#include"Date.h"
#include"Student.h"
#include"Course.h"
#include"ElectiveCourse.h"
#include"ObligatoryCourse.h"

class Console
{
    public:
        Console();
        virtual ~Console();
        int run();
    private:
        int displayMenu() const;
        void showOption() const;
        void showCourse(int) const;
        bool setCourseScore();
        void selectCourse(int);
        Console& buildStudent();
        Console& buildCourse();
        void searchStudentGrade();
        void searchStudentGPA();

        Student *student;
        ObligatoryCourse *oc[MAX_SIZE];
        ElectiveCourse *ec[MAX_SIZE];
        int ocNum;
        int ecNum;
        int option;
};

#endif // CONSOLE_H
