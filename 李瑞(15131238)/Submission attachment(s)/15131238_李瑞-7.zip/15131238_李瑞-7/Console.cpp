#include "Console.h"
#include<typeinfo>
#include<cstdio>
#include<fstream>

Console::Console() {}

Console::~Console() {}

int Console::run()
{
    buildStudent(); //��������쳣�������ơ�
    buildCourse();
    showOption();
    ofstream outStu("dataout.txt",ios::out);
    while(1)
    {
        cin>>option;
        if(cin.fail() || option<0 || option>6)
        {
            cout<<"Wrong input!"<<endl;
            cin.clear();
            cin.sync();
        }
        else if(option==0) break;
        else if(option==3)
        {
            cout<<*student;
            outStu<<*student;
        }
        else if(option==4) setCourseScore(); //���ÿγ̳ɼ����쳣�������ơ�
        else if(option==5) searchStudentGrade();
        else if(option==6) searchStudentGPA();
        else selectCourse(option);
    }
    return 0;
}

Console& Console::buildStudent()
{
    char *stuname=new char[20];
    Date studate;
    cout<<"Please enter the student name:";
    gets(stuname);
    while(1)
    {
        try
        {
            cout<<"Please enter the student birthday:";
            cin>>studate;
            student=new Student(stuname,studate);
            break;
        }
        catch(MyException &ex)
        {
            cout<<"Exception occurred:"<<endl<<ex.what()<<endl;
            cout<<endl<<"please input angin"<<endl;
        }
    }
    return *this;
}

Console& Console::buildCourse()
{
    ifstream inCourse("datain.txt",ios::in);
    string course;
    int credit;
    int cnt=0;
    while(inCourse>>course>>credit)
    {
        if(cnt<3) oc[cnt]=new ObligatoryCourse(course,credit);
        else ec[cnt-3]=new ElectiveCourse(course,credit);
        cnt++;
    }
    ocNum=ecNum=3;
    return *this;
}

void Console::showOption() const
{
    cout<<"##########student select course system##########"<<endl;
    cout<<"1.choose obligatory courses"<<endl;
    cout<<"2.choose elective courses"<<endl;
    cout<<"3.view the schedule"<<endl;
    cout<<"4.set course grade"<<endl;
    cout<<"5.Query the student's grade"<<endl;
    cout<<"6.Search the student's GPA"<<endl;
    cout<<"0.exit system"<<endl;
    cout<<"Please select the operation(0~6):";
}

void Console::showCourse(int op) const
{
    if(op==1) for(int i=0;i<ocNum;i++) cout<<i+1<<"."<<*oc[i]<<endl;
    else for(int i=0;i<ecNum;i++) cout<<i+1<<"."<<*ec[i]<<endl;
    cout<<"0.quit choose courses"<<endl;
}

bool Console::setCourseScore()
{
    if(student->getCourseNumber()==0) return false;
    else
    {
        cout<<*student;
        for(int i=0;i<student->getCourseNumber();i++)
        {
            int xuhao;
            while(1)
            {
                try
                {
                    cout<<"Please enter course id:";
                    cin>>xuhao;
                    if(xuhao<1 || xuhao>student->getCourseNumber())
                        throw MyException();
                    break;
                }
                catch(MyException &ex)
                {
                    cout<<"Exception occurred:"<<endl<<ex.what()<<endl;
                    cout<<endl<<"please input angin"<<endl;
                }
            }
            cout<<"Please input score:";
            if(typeid(ObligatoryCourse)==typeid(*(student->getCourseList(xuhao))))
            {
                int score;
                while(1)
                {
                    try
                    {
                        cin>>score;
                        if(score<0 || score>100)
                            throw MyException();
                        break;
                    }
                    catch(MyException &ex)
                    {
                        cout<<"Exception occurred:"<<endl<<ex.what()<<endl;
                        cout<<endl<<"please input angin"<<endl;
                    }
                }
                dynamic_cast<ObligatoryCourse*>(student->getCourseList(xuhao))->setMark(score);
            }
            else if(typeid(ElectiveCourse)==typeid(*(student->getCourseList(xuhao))))
            {
                char grade;
                while(1)
                {
                    try
                    {
                        cin>>grade;
                        if(grade<'A' || grade>'E')
                            throw MyException();
                        break;
                    }
                    catch(MyException &ex)
                    {
                        cout<<"Exception occurred:"<<endl<<ex.what()<<endl;
                        cout<<endl<<"please input angin"<<endl;
                    }
                }
                dynamic_cast<ElectiveCourse*>(student->getCourseList(xuhao))->setGrade(grade);
            }
            cout<<"set successfully."<<endl;
        }
        cout<<"all course grades set up."<<endl;
    }
    return true;
}

void Console::selectCourse(int op)
{
    showCourse(op);
    int xuhao;
    cout<<"Please enter the course number:";
    while(cin>>xuhao)
    {
        if(xuhao!=0)
        {
            if(op==1)
            {
                if(xuhao<0 || xuhao>ocNum)
                {
                    cout<<"invalid input"<<endl<<"please input angin"<<endl;
                    continue;
                }
                student->addCourse(oc[xuhao-1]);
            }
            else
            {
                if(xuhao<0 || xuhao>ecNum)
                {
                    cout<<"invalid input"<<endl<<"please input angin"<<endl;
                    continue;
                }
                student->addCourse(ec[xuhao-1]);
            }
            cout<<"chooose course successfully."<<endl;
            cout<<"Please continue:";
        }
        else
        {
            cout<<"quit successfully."<<endl;
            break;
        }
    }
}

void Console::searchStudentGPA()
{
    cout<<"GPA:"<<student->calcCredit()<<endl;
}

void Console::searchStudentGrade()
{
    cout<<*student;
}
