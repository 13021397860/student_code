#include "myexception.h"

MyException::MyException() :runtime_error("invaild input")
{
    //ctor
}
