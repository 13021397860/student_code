#ifndef STUDENT_H
#define STUDENT_H

#include"Date.h"
#include"Course.h"
#include"ElectiveCourse.h"
#include"ObligatoryCourse.h"
#define MAX_SIZE 20

class Student
{
    public:
        Student();
        Student(char*,Date&);
        Student(Student&);
        virtual ~Student();

        void setStudentName(const char*);
        void setStudentDate(const Date&);

        char* getStudentName() const;
        int getStudentCounts() const;
        int getCourseNumber() const;
        const Date& getBirthDate() const;
        Course* getCourseList(int) const;

        //void printStudent() const;
        //void printCourse() const;
        Student& addCourse(Course *);
        //Student& addCourse(const string &courseName,int creditHour);
        bool removeCourse(int);
        double calcCredit();
        friend ostream& operator<<(ostream&,const Student&);

    private:
         char *name;
         const Date birthDate;
         static int counts;
         Course *courseList[MAX_SIZE];
         int courseNumber;
};

#endif // STUDENT_H
