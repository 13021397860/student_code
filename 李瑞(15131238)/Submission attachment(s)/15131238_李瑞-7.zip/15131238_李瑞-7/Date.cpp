#include<iostream>
#include "Date.h"
#include"myexception.h"
using namespace std;

Date::Date(int _year,int _month,int _day)
{
    setDate(_year,_month,_day);
}

Date::Date(const Date& d)
{
    setDate(d.year,d.month,d.day);
}

Date::~Date()
{
    cout<<"Destruct the DataObject."<<endl;
}

void Date::setDate(int _year,int _month,int _day)
{
    year=_year;
    month=_month;
    day=_day;
    //if(!checkDate()) resetDate();
    if(!checkDate())
        throw MyException();
}
/*
void Date::resetDate()
{
    year=1900;
    month=1;
    day=1;
}
*/
int Date::getYear() const
{
    return year;
}

int Date::getMonth() const
{
    return month;
}

int Date::getDay() const
{
    return day;
}

bool Date::isLeapYear() const
{
    if(year%400==0 || (year%4==0 && year%100 !=0))
        return true;
    else
        return false;
}

bool Date::checkDate() const
{
    bool rt=true;
    int dayPerMonth[13]={0,31,28,31,30,31,30,31,31,30,31,30,31};
    if(month<1 || month>12) rt=false;
    else if(isLeapYear() && day==29 && month==2) rt=true;
    else if(day<1 || day>dayPerMonth[month]) rt=false;
    return rt;
}

void Date::nextDay()
{
    day++;
    if(!checkDate())
    {
        day=1;
        month++;
        if(!checkDate())
        {
            day=1;
            month=1;
            year++;
        }
    }
}
/*
void Date::print() const
{
    cout<<getYear()<<'/'<<getMonth()<<'/'<<getDay()<<endl;
}
*/
ostream &operator<<(ostream &output,const Date &date)
{
    output<<date.getYear()<<'-'<<date.getMonth()<<'-'<<date.getDay();
    return output;
}

istream &operator>>(istream &input,Date &date)
{
    input>>date.year>>date.month>>date.day;
    return input;
}

Date& Date::operator+(int &days)
{
    for(int i=0;i<days;i++) this->nextDay();
    return *this;
}

Date& Date::operator++()
{
    this->nextDay();
    return *this;
}

Date Date::operator++(int a)
{
    Date temp=*this;
    this->nextDay();
    return temp;
}
