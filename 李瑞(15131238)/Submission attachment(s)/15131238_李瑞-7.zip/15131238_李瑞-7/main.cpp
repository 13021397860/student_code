#include<iostream>
#include"Console.h"
using namespace std;

int main()
{
    Console console;
    int result=console.run();
    return result;
}
