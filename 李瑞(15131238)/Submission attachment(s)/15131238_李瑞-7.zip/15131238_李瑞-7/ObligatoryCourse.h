#ifndef OBLIGATORYCOURSE_H
#define OBLIGATORYCOURSE_H

#include"Course.h"

class ObligatoryCourse : public Course
{
    public:
        ObligatoryCourse(const string _name="temp",int _creditHour=0,int _mark=-1);
        virtual ~ObligatoryCourse();
        void setMark(int _mark);
        virtual int getScore() const;

    private:
        int mark;
};

#endif // OBLIGATORYCOURSE_H
