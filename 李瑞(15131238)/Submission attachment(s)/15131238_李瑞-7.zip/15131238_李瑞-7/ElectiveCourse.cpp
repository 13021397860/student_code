#include "ElectiveCourse.h"
#include<iostream>
using namespace std;

ElectiveCourse::ElectiveCourse(const string _name,int _creditHour,char _grade)
    :Course(_name,_creditHour)
{
    setGrade(_grade);
}

ElectiveCourse::~ElectiveCourse()
{
    cout<<"Destruct the ElectiveCourseObject."<<endl;
}

void ElectiveCourse::setGrade(char _grade)
{
    grade=_grade;
}

int ElectiveCourse::getScore() const
{
    int temp=-1;
    switch(grade)
    {
        case 'A': temp=95;break;
        case 'B': temp=85;break;
        case 'C': temp=75;break;
        case 'D': temp=65;break;
        case 'E': temp=55;break;
    }
    return temp;
}
