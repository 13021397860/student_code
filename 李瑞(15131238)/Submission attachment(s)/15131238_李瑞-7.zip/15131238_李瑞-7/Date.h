#ifndef DATE_H
#define DATE_H
#include<iostream>
using namespace std;

class Date
{
    public:
        Date(int yr=1900,int mn=1,int dy=1);
        Date(const Date&);
        virtual ~Date();

        void setDate(int, int, int);
        //void resetDate();

		int getYear() const;
		int getMonth() const;
		int getDay() const;

		bool isLeapYear() const;
		bool checkDate() const;
		void nextDay();
		//void print() const;

		friend ostream &operator<<(ostream &,const Date &);
		friend istream &operator>>(istream &,Date &);

		Date& operator+(int &);
		Date& operator++();
		Date operator++(int); //postfix increment operator

    private:
        int year;
        int month;
        int day;
};

#endif // DATE_H
