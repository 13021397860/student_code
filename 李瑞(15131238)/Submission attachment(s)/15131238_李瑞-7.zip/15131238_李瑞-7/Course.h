#ifndef COURSE_H
#define COURSE_H

#include<string>
#include"myexception.h"
using namespace std;

class Course
{
    public:
        Course(const string _name="temp",int _creditHour=0);
        virtual ~Course();
        string getName() const;
        int getCreditHour() const;
        void setName(string _name);
        void setCreditHour(int _creditHour);
        virtual int getScore() const = 0;

        friend ostream& operator<<(ostream&,const Course&);

    private:
        string name;
        int creditHour;
};

#endif // COURSE_H
