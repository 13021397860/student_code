#include "ObligatoryCourse.h"
#include<iostream>
using namespace std;

ObligatoryCourse::ObligatoryCourse(const string _name,int _creditHour,int _mark)
    :Course(_name,_creditHour)
{
    setMark(_mark);
}

ObligatoryCourse::~ObligatoryCourse()
{
    cout<<"Destruct the ObligatoryCourseObject."<<endl;
}

void ObligatoryCourse::setMark(int _mark)
{
    mark=_mark;
}

int ObligatoryCourse::getScore() const
{
    return mark;
}
