#include<iostream>
#include<cstring>
#include<fstream>
#include "Student.h"
#include<typeinfo>
int Student::counts=0;
using namespace std;

Student::Student()
    :birthDate(1997,9,3)
{
    char *pName=new char[6];
    strcpy(pName,"lirui");
    setStudentName(pName);
    courseNumber=0;
    counts++;
}


Student::Student(char* _name,Date& _birthDate)
    :birthDate(_birthDate)
{
    name=NULL;
    setStudentName(_name);
    courseNumber=0;
    counts++;
}

Student::Student(Student& stu)
    :birthDate(stu.birthDate)
{
    name=NULL;
    setStudentName(stu.name);
    courseNumber=0;
    counts++;
}

Student::~Student()
{
    delete []name;
    cout<<"Destruct the StudentObject."<<endl;
    counts--;
}

void Student::setStudentName(const char *_name)
{
    if(name) delete []name;
    name =new char[strlen(_name)+1];
    strcpy(name,_name);
}

char* Student::getStudentName() const
{
    return name;
}

int Student::getStudentCounts() const
{
    return counts;  //need to initialize counts first
}

int Student::getCourseNumber() const
{
    return courseNumber;
}

const Date& Student::getBirthDate() const
{
    return birthDate;
}

Course* Student::getCourseList(int i) const
{
    return courseList[i-1];
}
/*
void Student::printStudent() const
{
    cout<<getStudentName()<<" "<<birthDate.getYear()<<"-"<<
        birthDate.getMonth()<<"-"<<birthDate.getDay()<<" "<<getStudentCounts()<<endl;
}

void Student::printCourse() const
{
    for(int i=0;i<courseNumber;i++)
    {
        cout<<setw(10)<<i+1<<'.';
        cout.setf(ios::left);
        cout<<setw(20)<<"�γ�����"<<courseList[i]->getName();
        cout<<setw(10)<<"ѧ�֣�"<<courseList[i]->getCreditHour();
        cout<<endl;
        cout.setf(ios::right);
    }
}
*/
Student& Student::addCourse(Course *course)
{
    if(courseNumber<MAX_SIZE)
    {
        courseList[courseNumber]=course;
        courseList[courseNumber]->setName(course->getName());
        courseList[courseNumber]->setCreditHour(course->getCreditHour());
        courseNumber++;
    }
    else cout<<"Exceeds the maximum number of optional courses."<<endl;
    return *this;
}
/*
Student& Student::addCourse(const string &courseName,int creditHour)
{
    if(courseNumber<MAX_SIZE)
    {
        courseList[courseNumber]=new Course;
        courseList[courseNumber]->setName(courseName);
        courseList[courseNumber]->setCreditHour(creditHour);
        courseNumber++;
    }
    else cout<<"Exceeds the maximum number of optional courses."<<endl;
    return *this;
}
*/
ostream& operator<<(ostream& output,const Student& stu)
{
    output<<"name:"<<stu.getStudentName();
    output<<" ";
    output<<"birthdate:"<<stu.getBirthDate()<<endl;
    output<<"The selected course information is as follows:"<<endl;
    for(int i=0;i<stu.getCourseNumber();i++) output<<i+1<<'.'<<*stu.courseList[i]<<endl;
    return output;
}

bool Student::removeCourse(int num)
{
    if(num<=courseNumber)
    {
        delete courseList[num-1];
        for(int i=num;i<courseNumber;i++) courseList[i-1]=courseList[i];
        courseList[courseNumber-1]=NULL;
        courseNumber--;
        return true;
    }
    return false;
}

double Student::calcCredit()
{
    double oc_Weight=0.6;
    double ec_Weight=0.4;
    double oc_sum=0;
    double ec_sum=0;
    int oc_credit=0;
    int ec_number=0;
    double credit=0;
    for(int i=0;i<getCourseNumber();i++)
    {
        if(typeid(ObligatoryCourse)==typeid(*courseList[i]))
        {
            oc_sum+=courseList[i]->getScore()*courseList[i]->getCreditHour();
            oc_credit+=courseList[i]->getCreditHour();
        }
        else if(typeid(ElectiveCourse)==typeid(*courseList[i]))
        {
            ec_sum+=courseList[i]->getScore();
            ec_number++;
        }
    }
    oc_sum=oc_sum/oc_credit;
    ec_sum=ec_sum/ec_number;
    credit=oc_sum*oc_Weight+ec_sum*ec_Weight;
    return credit;
}

















