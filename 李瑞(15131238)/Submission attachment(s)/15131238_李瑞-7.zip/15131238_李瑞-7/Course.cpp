#include "Course.h"
#include<string>
#include<iostream>
#include<fstream>
using namespace std;

Course::Course(const string _name,int _creditHour)
{
    setName(_name);
    setCreditHour(_creditHour);
}

Course::~Course()
{
    cout<<"Destruct the CourseObject."<<endl;
}

string Course::getName() const
{
    return name;
}

int Course::getCreditHour() const
{
    return creditHour;
}

void Course::setName(string _name)
{
    name=_name;
}

void Course::setCreditHour(int _creditHour)
{
    creditHour=_creditHour;
}

ostream& operator<<(ostream& output,const Course& course)
{
    output<<"course name:"<<course.getName();
    output<<" ";
    output<<"credit hours:"<<course.getCreditHour();
    output<<" ";
    if(course.getScore()!=-1) output<<"score:"<<course.getScore();
    return output;
}
